<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pendaftaran;
use Illuminate\Support\Facades\Storage;

class PendaftaranAdminController extends Controller
{
    /**
     * Tampilkan daftar pendaftaran
     */
    public function index(Request $request)
    {
        $query = Pendaftaran::with('jurusan')->orderBy('created_at', 'desc');

        // Filter berdasarkan status
        if ($request->filled('status_pembayaran')) {
            $query->where('status_pembayaran', $request->status_pembayaran);
        }

        if ($request->filled('status_pendaftaran')) {
            $query->where('status_pendaftaran', $request->status_pendaftaran);
        }

        // Search
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('nama_lengkap', 'like', "%{$search}%")
                  ->orWhere('nisn', 'like', "%{$search}%")
                  ->orWhere('kode_pendaftaran', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $pendaftarans = $query->paginate(20);

        return view('admin.pendaftaran.index', compact('pendaftarans'));
    }

    /**
     * Tampilkan detail pendaftaran
     */
    public function show($id)
    {
        $pendaftaran = Pendaftaran::with('jurusan')->findOrFail($id);
        return view('admin.pendaftaran.show', compact('pendaftaran'));
    }

    /**
     * Update status pendaftaran
     */
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status_pendaftaran' => 'required|in:draft,menunggu_pembayaran,verifikasi_dokumen,diterima,ditolak',
            'status_pembayaran' => 'required|in:pending,paid,failed,expired',
            'catatan_admin' => 'nullable|string',
        ]);

        $pendaftaran = Pendaftaran::findOrFail($id);
        
        $updateData = [
            'status_pendaftaran' => $request->status_pendaftaran,
            'status_pembayaran' => $request->status_pembayaran,
            'catatan_admin' => $request->catatan_admin,
        ];

        // If status changed to paid, set paid_at if not set
        if ($request->status_pembayaran == 'paid' && !$pendaftaran->paid_at) {
            $updateData['paid_at'] = now();
        } 
        // If status changed from paid to something else, clear paid_at (optional, depends on logic)
        // Let's keep paid_at as history even if status changes back for now, or clear it? 
        // Usually if failed/expired we might want to keep history or clear. 
        // For simplicity let's only set it when paid.

        $pendaftaran->update($updateData);

        return back()->with('success', 'Status pendaftaran berhasil diupdate.');
    }

    /**
     * Download dokumen
     */
    public function downloadDocument($id, $type)
    {
        $pendaftaran = Pendaftaran::findOrFail($id);

        $filePath = match($type) {
            'ijazah' => $pendaftaran->ijazah_path,
            'akta' => $pendaftaran->akta_kelahiran_path,
            'kk' => $pendaftaran->kartu_keluarga_path,
            'foto' => $pendaftaran->pas_foto_path,
            'kip' => $pendaftaran->kip_path,
            'ktp' => $pendaftaran->ktp_ortu_path,
            'bukti_pembayaran' => $pendaftaran->bukti_pembayaran_path,
            default => null,
        };

        if (!$filePath || !Storage::disk('public')->exists($filePath)) {
            abort(404, 'File tidak ditemukan');
        }

        return Storage::disk('public')->download($filePath);
    }

    /**
     * Delete pendaftaran
     */
    public function destroy($id)
    {
        $pendaftaran = Pendaftaran::findOrFail($id);

        // Delete files
        $files = [
            $pendaftaran->ijazah_path,
            $pendaftaran->akta_kelahiran_path,
            $pendaftaran->kartu_keluarga_path,
            $pendaftaran->pas_foto_path,
            $pendaftaran->ktp_ortu_path,
        ];

        if ($pendaftaran->kip_path) {
            $files[] = $pendaftaran->kip_path;
        }

        if ($pendaftaran->bukti_pembayaran_path) {
            $files[] = $pendaftaran->bukti_pembayaran_path;
        }

        foreach ($files as $file) {
            if (Storage::disk('public')->exists($file)) {
                Storage::disk('public')->delete($file);
            }
        }

        $pendaftaran->delete();

        return redirect()->route('admin.pendaftaran.index')
            ->with('success', 'Pendaftaran berhasil dihapus.');
    }

    /**
     * Export data pendaftaran
     */
    public function export(Request $request)
    {
        $query = Pendaftaran::with('jurusan')->orderBy('created_at', 'desc');

        if ($request->filled('status_pembayaran')) {
            $query->where('status_pembayaran', $request->status_pembayaran);
        }

        if ($request->filled('status_pendaftaran')) {
            $query->where('status_pendaftaran', $request->status_pendaftaran);
        }

        $pendaftarans = $query->get();

        // Generate CSV
        $filename = 'pendaftaran_' . date('Y-m-d_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($pendaftarans) {
            $file = fopen('php://output', 'w');
            
            // Header
            fputcsv($file, [
                'Kode Pendaftaran', 'NISN', 'Nama Lengkap', 'Email', 'No HP',
                'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin', 'Alamat',
                'Nama Ayah', 'Pekerjaan Ayah', 'Nama Ibu', 'Pekerjaan Ibu',
                'Nama Wali', 'No HP Ortu', 'Alamat Ortu',
                'Sekolah Asal', 'Alamat Sekolah', 'Tahun Lulus', 'Rata-rata Nilai',
                'Jurusan', 'Prestasi', 'Alasan Memilih',
                'Status Pembayaran', 'Status Pendaftaran', 'Tanggal Daftar'
            ]);

            // Data
            foreach ($pendaftarans as $p) {
                fputcsv($file, [
                    $p->kode_pendaftaran,
                    $p->nisn,
                    $p->nama_lengkap,
                    $p->email,
                    $p->no_hp_siswa,
                    $p->tempat_lahir,
                    $p->tanggal_lahir->format('d-m-Y'),
                    $p->jenis_kelamin,
                    $p->alamat,
                    $p->nama_ayah,
                    $p->pekerjaan_ayah,
                    $p->nama_ibu,
                    $p->pekerjaan_ibu,
                    $p->nama_wali,
                    $p->no_hp_ortu,
                    $p->alamat_ortu,
                    $p->sekolah_asal,
                    $p->alamat_sekolah_asal,
                    $p->tahun_lulus,
                    $p->rata_rata_nilai,
                    $p->jurusan->name ?? '-',
                    $p->prestasi_ekstrakurikuler ?? '-',
                    $p->alasan_memilih,
                    $p->status_pembayaran,
                    $p->status_pendaftaran,
                    $p->created_at->format('d-m-Y H:i'),
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
