<?php $__env->startSection('title', 'Detail Berita'); ?>
<?php $__env->startSection('page-title', 'Detail Berita'); ?>
<?php $__env->startSection('page-description', 'Informasi lengkap berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <!-- Image Header -->
        <?php if($berita->image_path): ?>
            <div class="h-96 bg-gray-200 overflow-hidden">
                <img src="<?php echo e(asset($berita->image_path)); ?>" alt="<?php echo e($berita->title); ?>" class="w-full h-full object-cover">
            </div>
        <?php endif; ?>

        <div class="p-8 space-y-6">
            <!-- Header Info -->
            <div class="flex items-center justify-between pb-6 border-b border-gray-100">
                <div class="flex items-center space-x-3">
                    <span class="px-4 py-1 bg-blue-100 text-blue-800 text-sm font-semibold rounded-full">
                        <?php echo e($berita->category); ?>

                    </span>
                    <?php if($berita->jurusan): ?>
                        <span class="px-4 py-1 bg-yellow-100 text-yellow-800 text-sm font-semibold rounded-full">Jurusan: <?php echo e($berita->jurusan->name); ?></span>
                    <?php else: ?>
                        <span class="px-4 py-1 bg-gray-100 text-gray-600 text-sm font-semibold rounded-full">Umum</span>
                    <?php endif; ?>
                    <span class="text-gray-500 text-sm">
                        <i class="fas fa-calendar mr-2"></i><?php echo e($berita->posted_at ? $berita->posted_at->format('d F Y') : '-'); ?>

                    </span>
                </div>
                <div class="text-gray-500 text-sm">
                    <i class="fas fa-user mr-2"></i><?php echo e($berita->author); ?>

                </div>
            </div>

            <!-- Title -->
            <div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($berita->title); ?></h1>
                <p class="text-sm text-gray-400 font-mono">Slug: <?php echo e($berita->slug); ?></p>
            </div>

            <!-- Content -->
            <div class="prose max-w-none">
                <div class="text-gray-700 leading-relaxed whitespace-pre-line">
                    <?php echo e($berita->content); ?>

                </div>
                <?php
                    $hashtags = $berita->hashtags;
                    if (is_string($hashtags)) {
                        $decoded = json_decode($hashtags, true);
                        if (is_array($decoded)) $hashtags = $decoded;
                        else $hashtags = [];
                    }
                ?>
                <?php if($hashtags && is_array($hashtags) && count($hashtags)): ?>
                    <div class="mt-4">
                        <span class="text-xs text-gray-500 mr-2">Hashtag:</span>
                        <?php $__currentLoopData = $hashtags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-1">#<?php echo e(ltrim($tag, '#')); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Meta Info -->
            <div class="pt-6 border-t border-gray-100 grid grid-cols-2 gap-4 text-sm">
                <div>
                    <span class="text-gray-500">Dibuat:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($berita->created_at->format('d M Y H:i')); ?></span>
                </div>
                <div>
                    <span class="text-gray-500">Terakhir diupdate:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($berita->updated_at->format('d M Y H:i')); ?></span>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="bg-gray-50 px-8 py-4 flex justify-between items-center border-t border-gray-100">
            <a href="<?php echo e(route('admin.beritas.index')); ?>" class="px-4 py-2 text-gray-700 hover:text-gray-900 font-medium">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.beritas.edit', $berita->slug)); ?>" class="px-4 py-2 bg-yellow-50 text-yellow-600 rounded-lg hover:bg-yellow-100 transition-colors font-medium">
                    <i class="fas fa-edit mr-2"></i>Edit
                </a>
                <form action="<?php echo e(route('admin.beritas.destroy', $berita->slug)); ?>" method="POST" class="inline" 
                      onsubmit="return confirm('Apakah Anda yakin ingin menghapus berita ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors font-medium">
                        <i class="fas fa-trash mr-2"></i>Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\beritas\show.blade.php ENDPATH**/ ?>