<?php $__env->startSection('title', $jurusan->name . ' - SMK Taman Siswa Purwokerto'); ?>
<?php $__env->startSection('meta_description', \Illuminate\Support\Str::limit(strip_tags($jurusan->description), 160)); ?>

<?php $__env->startSection('content'); ?>

    <section class="section-padding" style="margin-top: 80px;">
        <div class="container">
            <!-- Breadcrumb -->
            <p style="margin-bottom: 2rem; color: var(--text-muted);">
                <a href="<?php echo e(route('landingpage')); ?>">Beranda</a> /
                <a href="<?php echo e(route('jurusan.index')); ?>">Jurusan</a> /
                <?php echo e($jurusan->name); ?>

            </p>

            <div>
                <h1 class="section-title mobile:text-xl" style="margin-bottom: 2rem;"><?php echo e($jurusan->name); ?></h1>

                
                <div class="image-slider-container" style="margin-bottom: 2rem;">
                    <div class="slider">
                        <?php $__currentLoopData = $jurusan->image_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slide <?php echo e($index === 0 ? 'active' : ''); ?>">
                                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($jurusan->name); ?> - Foto <?php echo e($index + 1); ?>"
                                    style="width: 100%; height: 450px; object-fit: cover; border-radius: var(--border-radius);">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="slider-dots" style="text-align: center; margin-top: 1rem;">
                        <?php $__currentLoopData = $jurusan->image_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="dot <?php echo e($index === 0 ? 'active' : ''); ?>"
                                onclick="currentSlide(<?php echo e($index); ?>)"></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div style="font-size: 1.1rem; color: var(--text-main); line-height: 1.8;">
                    <?php echo $jurusan->description; ?>


                    
                    <?php if(is_array($jurusan->subjects) && count($jurusan->subjects) > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin: 2rem 0 1rem 0;">Apa Yang Dipelajari?</h3>
                        <ul style="list-style: disc; padding-left: 1.5rem; margin-bottom: 2rem; color: var(--text-muted);">
                            <?php $__currentLoopData = $jurusan->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($subject); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                    
                    <?php if(is_array($jurusan->prospects) && count($jurusan->prospects) > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Prospek Karir</h3>
                        <p style="margin-bottom: 1.5rem; color: var(--text-muted);">
                            Lulusan <?php echo e($jurusan->name); ?> memiliki peluang kerja yang sangat luas di era digital ini, antara
                            lain sebagai:
                        </p>
                        <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $jurusan->prospects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="btn btn-secondary" style="font-size: 0.9rem;"><?php echo e($prospect); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(is_array($jurusan->certifications) && count($jurusan->certifications) > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Sertifikasi yang Bisa Diperoleh
                        </h3>
                        <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $jurusan->certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="btn btn-primary" style="font-size: 0.9rem;"><i class="fas fa-certificate"></i>
                                    <?php echo e($cert); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(is_array($jurusan->partners) && count($jurusan->partners) > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Mitra Jurusan</h3>
                        <div
                            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $jurusan->partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    style="text-align: center; padding: 1.25rem; background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--border-radius);">
                                    <?php if(isset($partner['logo'])): ?>
                                        <img src="<?php echo e(asset($partner['logo'])); ?>" alt="<?php echo e($partner['name'] ?? 'Mitra'); ?>"
                                            style="max-width: 100px; height: 60px; object-fit: contain; margin: 0 auto; display: block;">
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($beritas->count() > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Berita Jurusan</h3>
                        <div
                            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-hover"
                                    style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--border-radius); overflow: hidden;">
                                    <a href="<?php echo e(route('berita.show', $berita->slug)); ?>"
                                        style="text-decoration: none; color: inherit;">
                                        <?php if($berita->image_url): ?>
                                            <img src="<?php echo e($berita->image_url); ?>" alt="<?php echo e($berita->title); ?>"
                                                style="width: 100%; height: 200px; object-fit: cover;">
                                        <?php endif; ?>
                                        <div style="padding: 1.5rem;">
                                            <h4 style="color: var(--text-main); margin-bottom: 0.75rem;">
                                                <?php echo e(Str::limit($berita->title, 60)); ?>

                                            </h4>
                                            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                                                <?php echo e(Str::limit(strip_tags($berita->content), 100)); ?>

                                            </p>
                                            <div
                                                style="display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; color: var(--text-muted);">
                                                <span><i class="far fa-calendar"></i>
                                                    <?php echo e($berita->created_at->format('d M Y')); ?></span>
                                                <span style="color: var(--primary-blue);">Baca →</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($events->count() > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Event Jurusan</h3>
                        <div
                            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-hover"
                                    style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--border-radius); overflow: hidden;">
                                    <a href="<?php echo e(route('event.show', $event->slug)); ?>"
                                        style="text-decoration: none; color: inherit;">
                                        <?php if($event->image_url): ?>
                                            <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e($event->title); ?>"
                                                style="width: 100%; height: 200px; object-fit: cover;">
                                        <?php endif; ?>
                                        <div style="padding: 1.5rem;">
                                            <h4 style="color: var(--text-main); margin-bottom: 0.75rem;">
                                                <?php echo e(Str::limit($event->title, 60)); ?>

                                            </h4>
                                            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                                                <?php echo e(Str::limit(strip_tags($event->description), 100)); ?>

                                            </p>
                                            <div
                                                style="display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; color: var(--text-muted);">
                                                <span><i class="far fa-calendar"></i>
                                                    <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d M Y')); ?></span>
                                                <span style="color: var(--primary-blue);">Lihat →</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($galleries->count() > 0): ?>
                        <h3 style="color: var(--primary-blue-hover); margin-bottom: 1rem;">Galeri Jurusan</h3>
                        <div
                            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="position: relative; overflow: hidden; border-radius: var(--border-radius); cursor: pointer; aspect-ratio: 1/1; border: 1px solid var(--border-color);"
                                    onclick="window.location.href='<?php echo e(route('galeri.index')); ?>'">
                                    <?php if($gallery->image_url): ?>
                                        <img src="<?php echo e($gallery->image_url); ?>" alt="<?php echo e($gallery->title ?? 'Galeri'); ?>"
                                            class="gallery-img" style="width: 100%; height: 100%; object-fit: cover;">
                                    <?php endif; ?>
                                    <div
                                        style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to top, rgba(0,0,0,0.7), transparent); padding: 1rem 0.75rem; color: white;">
                                        <p style="margin: 0; font-size: 0.85rem;">
                                            <?php echo e(Str::limit($gallery->title ?? 'Galeri', 30)); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <div
                        style="text-align: center; margin-top: 3rem; padding: 2.5rem; background: var(--primary-blue); border-radius: var(--border-radius); color: white;">
                        <h3 style="margin-bottom: 0.75rem; color: white;">Tertarik dengan Jurusan Ini?</h3>
                        <p style="margin-bottom: 1.75rem; opacity: 0.95;">Daftar sekarang untuk tahun ajaran baru!</p>
                        <a href="<?php echo e(route('profilsekolah.ppdb-detail')); ?>" class="btn"
                            style="background: white; color: var(--primary-blue);">
                            Daftar Sekarang <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* Slider styles */
        .slider {
            position: relative;
            width: 100%;
        }

        .slide {
            display: none;
            animation: fadeIn 0.6s ease-in-out;
        }

        .slide.active {
            display: block;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .slider-dots {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
        }

        .dot {
            height: 10px;
            width: 10px;
            background-color: var(--border-color);
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.3s;
        }

        .dot.active {
            background-color: var(--primary-blue);
            width: 24px;
            border-radius: 5px;
        }

        .dot:hover {
            background-color: var(--primary-blue-hover);
        }

        .gallery-img {
            transition: transform 0.3s;
        }

        .gallery-img:hover {
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .slide img {
                height: 280px !important;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let slideIndex = 0;
        let slideTimer;

        function showSlides() {
            let slides = document.getElementsByClassName("slide");
            let dots = document.getElementsByClassName("dot");

            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove("active");
            }

            for (let i = 0; i < dots.length; i++) {
                dots[i].classList.remove("active");
            }

            slideIndex++;
            if (slideIndex > slides.length) {
                slideIndex = 1;
            }

            if (slides[slideIndex - 1]) {
                slides[slideIndex - 1].classList.add("active");
                dots[slideIndex - 1].classList.add("active");
            }

            slideTimer = setTimeout(showSlides, 5000);
        }

        function currentSlide(n) {
            clearTimeout(slideTimer);
            slideIndex = n;

            let slides = document.getElementsByClassName("slide");
            let dots = document.getElementsByClassName("dot");

            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove("active");
            }

            for (let i = 0; i < dots.length; i++) {
                dots[i].classList.remove("active");
            }

            slides[slideIndex].classList.add("active");
            dots[slideIndex].classList.add("active");

            slideTimer = setTimeout(showSlides, 5000);
        }

        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementsByClassName("slide").length > 0) {
                showSlides();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\jurusan-detail.blade.php ENDPATH**/ ?>