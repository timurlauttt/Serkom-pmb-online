<?php $__env->startSection('title', 'Pengumuman'); ?>
<?php $__env->startSection('page-title', 'Manajemen Pengumuman'); ?>
<?php $__env->startSection('page-description', 'Kelola semua pengumuman sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Actions -->
    <div class="flex justify-between items-center">
        <div>
            <h3 class="text-2xl font-bold text-gray-800">Daftar Pengumuman</h3>
            <p class="text-gray-600 mt-1">Total: <?php echo e($pengumumans->count()); ?> pengumuman</p>
        </div>
        <a href="<?php echo e(route('admin.pengumumans.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
            <i class="fas fa-plus mr-2"></i>Tambah Pengumuman
        </a>
    </div>

    <!-- Content: Table -->
    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Judul</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Post</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider" style="min-width:160px">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($pengumuman->title); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <i class="fas fa-calendar-alt mr-2"></i>
                                <?php echo e($pengumuman->posted_at ? $pengumuman->posted_at->format('d-m-Y') : $pengumuman->created_at->format('d-m-Y')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                <?php if(is_null($pengumuman->expires_at) || $pengumuman->expires_at->isFuture()): ?>
                                    <span class="px-2 py-1 text-xs font-semibold rounded bg-green-100 text-green-800">Aktif</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs font-semibold rounded bg-gray-100 text-gray-600">Kadaluarsa</span>
                                <?php endif; ?>
                                <?php if($pengumuman->expires_at): ?>
                                    <div class="text-xs text-gray-400 mt-1">Expires: <?php echo e($pengumuman->expires_at->format('d-m-Y')); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-right">
                                <div class="flex space-x-3 justify-end">
                                    <a href="<?php echo e(route('admin.pengumumans.show', $pengumuman->id)); ?>" class="text-blue-600 hover:text-blue-900 transition-colors" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.pengumumans.edit', $pengumuman->id)); ?>" class="text-yellow-600 hover:text-yellow-900 transition-colors" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.pengumumans.destroy', $pengumuman->id)); ?>" method="POST" class="inline"
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus pengumuman ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900 transition-colors" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4 mx-auto">
                                    <i class="fas fa-bullhorn text-gray-400 text-2xl"></i>
                                </div>
                                <div class="text-lg font-semibold text-gray-900">Belum ada pengumuman</div>
                                <p class="text-gray-500 mt-2">Mulai dengan menambahkan pengumuman pertama.</p>
                                <a href="<?php echo e(route('admin.pengumumans.create')); ?>" class="mt-4 inline-flex items-center px-4 py-2 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
                                    <i class="fas fa-plus mr-2"></i>Tambah Pengumuman
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\pengumumans\index.blade.php ENDPATH**/ ?>