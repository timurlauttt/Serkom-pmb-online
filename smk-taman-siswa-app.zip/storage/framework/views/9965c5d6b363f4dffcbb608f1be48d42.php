
<header>
    <div class="container">
        <nav>
            <a href="<?php echo e(route('landingpage')); ?>" class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo SMK Tamansiswa" style="height: 50px; width: auto;">
                <div style="display: flex; flex-direction: column; line-height: 1.2;">
                    <span style="font-size: 0.95rem; font-weight: 600; color: white;">SMK Tamansiswa</span>
                    <span style="font-size: 0.95rem; font-weight: 600; color: white;">Purwokerto</span>
                </div>
            </a>
            <div class="mobile-toggle" id="mobile-toggle">
                <i class="fas fa-bars"></i>
            </div>
            <ul class="nav-links" id="nav-links">
                
                
                <li><a href="<?php echo e(route('profilsekolah.profile')); ?>" class="<?php echo e(Request::routeIs('profilsekolah.profile') ? 'active' : ''); ?>">Tentang Kami</a></li>
                
                
                <li class="dropdown">
                    <a href="#" class="<?php echo e(Request::routeIs('jurusan.*') ? 'active' : ''); ?>">Jurusan <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <?php
                            $jurusans = \App\Models\Jurusan::orderBy('name')->get();
                        ?>
                        
                        <?php $__empty_1 = true; $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a href="<?php echo e(route('jurusan.show', $jurusan->slug)); ?>"><?php echo e($jurusan->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li><a href="<?php echo e(route('jurusan.index')); ?>">Semua Jurusan</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown">
                    <a href="#" class="<?php echo e(Request::routeIs('kesiswaan.*') ? 'active' : ''); ?>">Kesiswaan <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('profilsekolah.ekstrakulikuler')); ?>">Ekstrakulikuler</a></li>
                        <li><a href="<?php echo e(route('profilsekolah.prestasi')); ?>">Prestasi</a></li>
                    </ul>
                </li>
                

                
                <li class="dropdown">
                    <a href="#" class="<?php echo e(Request::routeIs('berita.*') || Request::routeIs('event.*') || Request::routeIs('pengumuman.*') ? 'active' : ''); ?>">Informasi <i class="fas fa-chevron-down"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('berita.index')); ?>">Berita</a></li>
                        <li><a href="<?php echo e(route('event.index')); ?>">Event</a></li>
                        <li><a href="<?php echo e(route('pengumuman.index')); ?>">Pengumuman</a></li>
                    </ul>
                </li>
                
                <li><a href="<?php echo e(route('profilsekolah.ppdb-detail')); ?>" class="<?php echo e(Request::routeIs('profilsekolah.ppdb*') ? 'active' : ''); ?>">PPDB</a></li>
                
                
                
                <li><a href="<?php echo e(route('galeri.index')); ?>" class="<?php echo e(Request::routeIs('galeri.*') ? 'active' : ''); ?>">Galeri</a></li>
                
                
                <li><a href="<?php echo e(route('tic.index')); ?>" class="<?php echo e(Request::routeIs('tic.*') ? 'active' : ''); ?>">TIC</a></li>
            </ul>
        </nav>
    </div>
</header><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\layouts\navbar.blade.php ENDPATH**/ ?>