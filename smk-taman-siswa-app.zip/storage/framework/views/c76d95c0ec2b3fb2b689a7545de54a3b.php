<?php $__env->startSection('title', 'Program Keahlian - SMK Taman Siswa Purwokerto'); ?>

<?php $__env->startSection('content'); ?>

    <section class="section-padding" style="margin-top: 80px;">
        <div class="container">
            <h1 class="section-title mobile:text-xl">Program Keahlian</h1>
            <p class="mobile:text-sm" style="margin-bottom: 3rem; color: var(--text-muted); max-width: 700px;">SMK Taman Siswa
                Purwokerto
                memiliki berbagai program keahlian yang dirancang untuk memenuhi kebutuhan industri saat ini dan masa
                depan.</p>

            <div class="programs-grid">
                <?php $__empty_1 = true; $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- Card Jurusan -->
                    <div class="card">
                        <div class="card-icon"><i class="fas fa-graduation-cap"></i></div>
                        <h3><?php echo e($jurusan->name); ?></h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">
                            <?php echo e(Str::limit(strip_tags($jurusan->description ?? ''), 100)); ?>

                        </p>
                        <a href="<?php echo e(route('jurusan.show', $jurusan->slug)); ?>"
                            style="color: var(--primary-blue-hover); font-weight: 600;">Lihat
                            Detail <i class="fas fa-arrow-right"></i></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Dummy Card jika kosong -->
                    <div class="card">
                        <div class="card-icon"><i class="fas fa-briefcase"></i></div>
                        <h3>Layanan Perbankan</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Program keahlian perbankan dengan focus
                            pada pelayanan nasabah dan operasional perbankan</p>
                        <a href="#" style="color: var(--primary-blue-hover); font-weight: 600;">Lihat Detail <i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card">
                        <div class="card-icon"><i class="fas fa-hotel"></i></div>
                        <h3>Perhotelan</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Mempersiapkan tenaga professional di
                            bidang perhotelan dengan standar internasional</p>
                        <a href="#" style="color: var(--primary-blue-hover); font-weight: 600;">Lihat Detail <i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card">
                        <div class="card-icon"><i class="fas fa-plane"></i></div>
                        <h3>Usaha Layanan Wisata</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Keahlian dalam industri pariwisata dan
                            travel agent untuk karir global</p>
                        <a href="#" style="color: var(--primary-blue-hover); font-weight: 600;">Lihat Detail <i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\jurusan.blade.php ENDPATH**/ ?>