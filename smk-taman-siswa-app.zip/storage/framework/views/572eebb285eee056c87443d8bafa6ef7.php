<?php $__env->startSection('title', 'Fasilitas - SMK Taman Siswa Purwokerto'); ?>

<?php $__env->startSection('content'); ?>


<?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'FASILITAS SEKOLAH','subtitle' => 'Sarana dan prasarana lengkap untuk mendukung pembelajaran optimal','breadcrumbs' => [
        ['title' => 'Profil', 'url' => '#'],
        ['title' => 'Fasilitas', 'url' => route('profilsekolah.fasilitas')]
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'FASILITAS SEKOLAH','subtitle' => 'Sarana dan prasarana lengkap untuk mendukung pembelajaran optimal','breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['title' => 'Profil', 'url' => '#'],
        ['title' => 'Fasilitas', 'url' => route('profilsekolah.fasilitas')]
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

<section class="section">
    <div class="container">
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 2rem;">

            
            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-chalkboard-teacher" style="font-size: 5rem; color: white; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Ruang Kelas Modern</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Dilengkapi dengan AC, proyektor, dan fasilitas multimedia untuk pembelajaran yang nyaman dan interaktif.
                    </p>
                    <ul style="color: #666; font-size: 0.9rem; padding-left: 1.25rem;">
                        <li>Kapasitas 36 siswa</li>
                        <li>AC & Proyektor</li>
                        <li>Wi-Fi gratis</li>
                    </ul>
                </div>
            </div>

            
            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-laptop-code" style="font-size: 5rem; color: white; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Laboratorium Komputer</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Lab komputer dengan perangkat terbaru untuk mendukung pembelajaran praktik teknologi informasi.
                    </p>
                    <ul style="color: #666; font-size: 0.9rem; padding-left: 1.25rem;">
                        <li>40 Unit komputer</li>
                        <li>Software terkini</li>
                        <li>Internet cepat</li>
                    </ul>
                </div>
            </div>

            
            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-book-reader" style="font-size: 5rem; color: white; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Perpustakaan</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Koleksi buku lengkap dan ruang baca nyaman untuk menunjang literasi siswa.
                    </p>
                    <ul style="color: #666; font-size: 0.9rem; padding-left: 1.25rem;">
                        <li>5000+ koleksi buku</li>
                        <li>Ruang baca ber-AC</li>
                        <li>E-library</li>
                    </ul>
                </div>
            </div>

            
            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-utensils" style="font-size: 5rem; color: white; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Kantin Sekolah</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Kantin bersih dan sehat dengan menu makanan bergizi dan harga terjangkau.
                    </p>
                </div>
            </div>

            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-mosque" style="font-size: 5rem; color: white; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Musholla</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Tempat ibadah yang nyaman dan bersih untuk kegiatan keagamaan siswa dan guru.
                    </p>
                </div>
            </div>

            <div style="background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.3s;">
                <div style="height: 200px; background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-futbol" style="font-size: 5rem; color: #667eea; opacity: 0.9;"></i>
                </div>
                <div style="padding: 1.5rem;">
                    <h4 style="margin-bottom: 1rem; color: #333;">Lapangan Olahraga</h4>
                    <p style="color: #666; line-height: 1.6; margin-bottom: 1rem;">
                        Area olahraga untuk berbagai aktivitas fisik dan pengembangan bakat siswa.
                    </p>
                </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .container>div>div {
        transition: all 0.3s;
    }

    .container>div>div:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15) !important;
    }

    @media (max-width: 768px) {
        .container>div {
            grid-template-columns: 1fr !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\fasilitas.blade.php ENDPATH**/ ?>