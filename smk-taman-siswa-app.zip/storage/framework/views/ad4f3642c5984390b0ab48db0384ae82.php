<?php $__env->startSection('title', 'Detail Jurusan'); ?>
<?php $__env->startSection('page-title', 'Detail Jurusan'); ?>
<?php $__env->startSection('page-description', 'Informasi lengkap jurusan'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <!-- Image Header -->
        <div class="h-64 bg-gradient-to-br from-indigo-500 to-purple-600 relative overflow-hidden flex items-center justify-center gap-4">
            <?php $__currentLoopData = [$jurusan->photo_path, $jurusan->photo_path_2, $jurusan->photo_path_3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($img): ?>
                    <img src="<?php echo e(asset($img)); ?>" alt="<?php echo e($jurusan->name); ?>" class="h-48 w-48 object-contain bg-white rounded-lg shadow border p-2">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$jurusan->photo_path && !$jurusan->photo_path_2 && !$jurusan->photo_path_3): ?>
                <div class="flex-1 flex items-center justify-center">
                    <i class="fas fa-book-open text-white text-6xl opacity-50"></i>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-8 space-y-6">
            <!-- Header Info -->
            <div class="pb-6 border-b border-gray-100">
                <h1 class="text-3xl font-bold text-gray-900 mb-2"><?php echo e($jurusan->name); ?></h1>
                <p class="text-sm text-gray-400 font-mono">Slug: <?php echo e($jurusan->slug); ?></p>
            </div>

            <!-- Description -->
            <div>
                <label class="text-sm font-medium text-gray-500 mb-2 block">Deskripsi</label>
                <div class="text-gray-700 leading-relaxed whitespace-pre-line">
                    <?php echo e($jurusan->description); ?>

                </div>
            </div>

            <!-- Mata Pelajaran -->
            <?php if($jurusan->subjects): ?>
                <div>
                    <label class="text-sm font-medium text-gray-500 mb-3 block">Mata Pelajaran</label>
                    <div class="flex flex-wrap gap-2">
                        <?php if(is_array($jurusan->subjects)): ?>
                            <?php $__currentLoopData = $jurusan->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-4 py-2 bg-indigo-100 text-indigo-800 text-sm font-medium rounded-lg">
                                    <i class="fas fa-book mr-2"></i><?php echo e($subject); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = explode(',', $jurusan->subjects); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-4 py-2 bg-indigo-100 text-indigo-800 text-sm font-medium rounded-lg">
                                    <i class="fas fa-book mr-2"></i><?php echo e(trim($subject)); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Prospek Lulusan -->
            <?php if($jurusan->prospects): ?>
                <div>
                    <label class="text-sm font-medium text-gray-500 mb-2 block">Prospek Lulusan</label>
                    <ul class="list-disc pl-6 space-y-1">
                        <?php $__currentLoopData = (array)$jurusan->prospects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-gray-700"><?php echo e($p); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Mitra Jurusan -->
            <?php if($jurusan->partners): ?>
                <div>
                    <label class="text-sm font-medium text-gray-500 mb-2 block">Mitra Jurusan</label>
                    <div class="flex flex-wrap gap-4">
                        <?php $__currentLoopData = (array)$jurusan->partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col items-center">
                                <?php if(!empty($mitra['logo'])): ?>
                                    <img src="<?php echo e(asset($mitra['logo'])); ?>" alt="Logo <?php echo e($mitra['name'] ?? ''); ?>" class="w-16 h-16 object-contain bg-gray-100 rounded mb-1">
                                <?php endif; ?>
                                <span class="text-gray-700 text-sm"><?php echo e($mitra['name'] ?? ''); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Biaya SPP -->
            <?php if($jurusan->spp_fee): ?>
                <div>
                    <label class="text-sm font-medium text-gray-500 mb-2 block">Biaya SPP</label>
                    <div class="text-gray-700 font-semibold">Rp <?php echo e(number_format($jurusan->spp_fee,0,',','.')); ?></div>
                </div>
            <?php endif; ?>

            <!-- Sertifikasi -->
            <?php if($jurusan->certifications): ?>
                <div>
                    <label class="text-sm font-medium text-gray-500 mb-2 block">Sertifikasi yang Bisa Diperoleh</label>
                    <ul class="list-disc pl-6 space-y-1">
                        <?php $__currentLoopData = (array)$jurusan->certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-gray-700"><?php echo e($cert); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Meta Info -->
            <div class="pt-6 border-t border-gray-100 grid grid-cols-2 gap-4 text-sm">
                <div>
                    <span class="text-gray-500">Dibuat:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($jurusan->created_at->format('d M Y H:i')); ?></span>
                </div>
                <div>
                    <span class="text-gray-500">Terakhir diupdate:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($jurusan->updated_at->format('d M Y H:i')); ?></span>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="bg-gray-50 px-8 py-4 flex justify-between items-center border-t border-gray-100">
            <a href="<?php echo e(route('admin.jurusans.index')); ?>" class="px-4 py-2 text-gray-700 hover:text-gray-900 font-medium">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.jurusans.edit', $jurusan->id)); ?>" class="px-4 py-2 bg-yellow-50 text-yellow-600 rounded-lg hover:bg-yellow-100 transition-colors font-medium">
                    <i class="fas fa-edit mr-2"></i>Edit
                </a>
                <form action="<?php echo e(route('admin.jurusans.destroy', $jurusan->id)); ?>" method="POST" class="inline" 
                      onsubmit="return confirm('Apakah Anda yakin ingin menghapus jurusan ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors font-medium">
                        <i class="fas fa-trash mr-2"></i>Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\jurusans\show.blade.php ENDPATH**/ ?>