
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'info', // info, success, warning, danger
    'dismissible' => true,
    'icon' => null,
    'title' => null
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'info', // info, success, warning, danger
    'dismissible' => true,
    'icon' => null,
    'title' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $typeClasses = [
        'info' => 'alert-info',
        'success' => 'alert-success',
        'warning' => 'alert-warning',
        'danger' => 'alert-danger',
        'primary' => 'alert-primary',
    ];
    
    $iconMap = [
        'info' => 'fa-info-circle',
        'success' => 'fa-check-circle',
        'warning' => 'fa-exclamation-triangle',
        'danger' => 'fa-exclamation-circle',
        'primary' => 'fa-bell',
    ];
    
    $alertClass = $typeClasses[$type] ?? 'alert-info';
    $alertIcon = $icon ?? ($iconMap[$type] ?? 'fa-info-circle');
?>

<div <?php echo e($attributes->merge(['class' => "alert {$alertClass}" . ($dismissible ? ' alert-dismissible fade show' : '')])); ?> role="alert">
    <?php if($dismissible): ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <?php endif; ?>
    
    <div class="d-flex align-items-start">
        <?php if($alertIcon): ?>
            <i class="fa <?php echo e($alertIcon); ?> me-10 fs-20"></i>
        <?php endif; ?>
        
        <div class="flex-grow-1">
            <?php if($title): ?>
                <h5 class="alert-heading mb-5"><?php echo e($title); ?></h5>
            <?php endif; ?>
            
            <div><?php echo e($slot); ?></div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\components\alert.blade.php ENDPATH**/ ?>