<?php $__env->startSection('title', 'Desa Wisata'); ?>
<?php $__env->startSection('page-title', 'Manajemen Desa Wisata'); ?>
<?php $__env->startSection('page-description', 'Kelola semua data desa wisata'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Actions -->
    <div class="flex justify-between items-center">
        <div>
            <h3 class="text-2xl font-bold text-gray-800">Daftar Desa Wisata</h3>
            <p class="text-gray-600 mt-1">Total: <?php echo e($desawisata->count()); ?> desa wisata</p>
        </div>
        <a href="<?php echo e(route('admin.desa-wisata.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
            <i class="fas fa-plus mr-2"></i>Tambah Desa Wisata
        </a>
    </div>

    <!-- Content -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if($desawisata->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Foto</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alamat</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kota</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Harga Tiket</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jam Operasional</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $desawisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($desa->gambar): ?>
                                    <img src="<?php echo e(asset($desa->gambar)); ?>" alt="Foto Desa Wisata" class="h-16 w-24 object-cover rounded">
                                <?php else: ?>
                                    <span class="text-xs text-gray-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900"><?php echo e($desa->nama); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-700"><?php echo e($desa->alamat); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-700"><?php echo e($desa->kota); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-700"><?php echo e($desa->harga_tiket ? 'Rp ' . number_format($desa->harga_tiket,0,',','.') : '-'); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-700"><?php echo e($desa->jam_operasional ?? '-'); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="<?php echo e(route('admin.desa-wisata.show', ['desa_wisatum' => $desa->slug])); ?>" class="text-blue-600 hover:text-blue-900 transition-colors" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.desa-wisata.edit', ['desa_wisatum' => $desa->slug])); ?>" class="text-yellow-600 hover:text-yellow-900 transition-colors" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.desa-wisata.destroy', ['desa_wisatum' => $desa->slug])); ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus desa wisata ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900 transition-colors" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                    <i class="fas fa-map-marked-alt text-gray-400 text-2xl"></i>
                </div>
                <h5 class="text-lg font-semibold text-gray-900 mb-2">Belum ada desa wisata</h5>
                <p class="text-gray-500 mb-6">Mulai dengan menambahkan desa wisata pertama.</p>
                <a href="<?php echo e(route('admin.desa-wisata.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all font-medium inline-flex items-center">
                    <i class="fas fa-plus mr-2"></i>Tambah Desa Wisata
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\desa-wisata\index.blade.php ENDPATH**/ ?>