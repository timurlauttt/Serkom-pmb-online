<?php $__env->startSection('title', 'Brosur PPDB'); ?>
<?php $__env->startSection('page-title', 'Manajemen Brosur PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h3 class="text-2xl font-bold text-gray-800">Daftar Brosur PPDB</h3>
        <a href="<?php echo e(route('admin.ppdb_brosurs.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i>Tambah Brosur
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <?php if($brosurs->count() > 0): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Judul</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Tahun Ajaran</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Cover</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">File</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Order</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $brosurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brosur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($brosur->judul); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e(Str::limit($brosur->deskripsi, 50)); ?></div>
                        </td>
                        <td class="px-6 py-4 text-sm"><?php echo e($brosur->tahun_ajaran); ?></td>
                        <td class="px-6 py-4">
                            <?php if($brosur->path_gambar_brosur): ?>
                                <img src="<?php echo e(asset($brosur->path_gambar_brosur)); ?>" alt="Cover" class="h-10 w-10 object-cover rounded">
                            <?php else: ?>
                                <span class="text-xs text-gray-400">No Image</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <a href="<?php echo e(asset($brosur->file_path)); ?>" target="_blank" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-file-pdf mr-1"></i>Lihat PDF
                            </a>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded <?php echo e($brosur->is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                                <?php echo e($brosur->is_active ? 'Aktif' : 'Nonaktif'); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm"><?php echo e($brosur->order); ?></td>
                        <td class="px-6 py-4">
                            <div class="flex space-x-2">
                                <a href="<?php echo e(route('admin.ppdb_brosurs.edit', $brosur->id)); ?>" class="text-yellow-600 hover:text-yellow-800">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.ppdb_brosurs.destroy', $brosur->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus brosur ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-file-pdf text-gray-300 text-5xl mb-4"></i>
                <p class="text-gray-500">Belum ada brosur</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\admin\ppdb\brosurs\index.blade.php ENDPATH**/ ?>