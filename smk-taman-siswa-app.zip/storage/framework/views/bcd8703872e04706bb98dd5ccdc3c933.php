<?php $__env->startSection('title', 'Pengumuman - SMK Taman Siswa Purwokerto'); ?>

<?php $__env->startSection('content'); ?>

    <section class="section-padding" style="margin-top: 80px;">
        <div class="container">
            <h1 class="section-title mobile:text-xl">Pengumuman Sekolah</h1>

            <div class="search-container">
                <input type="text" id="searchInput" class="search-input" placeholder="Cari pengumuman...">
                <button class="btn btn-primary mobile:text-xs"><i class="fas fa-search"></i> Cari</button>
            </div>

            <div class="news-grid" id="pengumumanContainer">
                <?php $__empty_1 = true; $__currentLoopData = $pengumumans ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <!-- Item -->
                    <article class="news-card search-item">
                        <?php if($pengumuman->image_path): ?>
                            <img src="<?php echo e(asset($pengumuman->image_path)); ?>" alt="<?php echo e($pengumuman->title); ?>" class="news-img">
                        <?php else: ?>
                            <div class="news-img"
                                style="background: var(--bg-secondary); display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-blue-hover);"></i>
                            </div>
                        <?php endif; ?>
                        <div class="news-content">
                            <span class="news-meta" style="color: var(--primary-blue-hover);">
                                <?php if($pengumuman->expires_at && \Carbon\Carbon::parse($pengumuman->expires_at)->isPast()): ?>
                                    KADALUARSA
                                <?php else: ?>
                                    PENGUMUMAN PENTING
                                <?php endif; ?>
                            </span>
                            <h3 class="news-title mobile:text-lg"><?php echo e($pengumuman->title); ?></h3>
                            <p class="mobile:text-sm"
                                style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                                <?php echo e(Str::limit(strip_tags($pengumuman->content ?? ''), 100)); ?>

                            </p>
                            <div class="mobile:text-xs"
                                style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 0.5rem;">
                                <i class="far fa-calendar"></i>
                                <?php echo e(\Carbon\Carbon::parse($pengumuman->posted_at)->format('d M Y')); ?>

                                <?php if($pengumuman->expires_at): ?>
                                    <span style="margin-left: 1rem;">
                                        <i class="far fa-clock"></i> Berlaku hingga
                                        <?php echo e(\Carbon\Carbon::parse($pengumuman->expires_at)->format('d M Y')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('pengumuman.show', $pengumuman->slug)); ?>" class="btn-link"
                                style="font-size: 0.9rem; color: var(--primary-blue-hover);">Lihat Detail</a>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Dummy Data jika tidak ada pengumuman -->
                    <article class="news-card search-item">
                        <div class="news-img"
                            style="background: var(--bg-secondary); display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-blue-hover);"></i>
                        </div>
                        <div class="news-content">
                            <span class="news-meta" style="color: var(--primary-blue-hover);">PENGUMUMAN PENTING</span>
                            <h3 class="news-title">Pengumuman Akan Segera Hadir</h3>
                            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">Informasi penting
                                seputar kegiatan sekolah akan diumumkan di sini...</p>
                            <a href="#" class="btn-link"
                                style="font-size: 0.9rem; color: var(--primary-blue-hover);">Lihat Detail</a>
                        </div>
                    </article>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if(isset($pengumumans) && method_exists($pengumumans, 'links')): ?>
                <div class="pagination-container" style="margin-top: 3rem; display: flex; justify-content: center;">
                    <?php echo e($pengumumans->links('vendor.pagination.custom')); ?>

                </div>
            <?php endif; ?>

        </div>
    </section>

    <style>
        .pagination-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 3rem;
        }

        .pagination-container nav {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .pagination-container ul {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 0.5rem;
            flex-wrap: wrap;
            justify-content: center;
        }

        .pagination-container li {
            margin: 0;
        }

        .pagination-container a,
        .pagination-container span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            height: 40px;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            font-size: 0.95rem;
        }

        .pagination-container a {
            background: white;
            color: var(--primary-blue);
            border: 2px solid #e5e7eb;
        }

        .pagination-container a:hover {
            background: var(--primary-blue);
            color: white;
            border-color: var(--primary-blue);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .pagination-container .active span {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-blue-hover) 100%);
            color: white;
            border: 2px solid var(--primary-blue);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .pagination-container .disabled span {
            background: #f3f4f6;
            color: #9ca3af;
            border: 2px solid #e5e7eb;
            cursor: not-allowed;
        }

        .pagination-container svg {
            width: 20px;
            height: 20px;
        }

        @media (max-width: 768px) {

            .pagination-container a,
            .pagination-container span {
                min-width: 36px;
                height: 36px;
                padding: 0.4rem 0.8rem;
                font-size: 0.875rem;
            }
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\pengumuman.blade.php ENDPATH**/ ?>