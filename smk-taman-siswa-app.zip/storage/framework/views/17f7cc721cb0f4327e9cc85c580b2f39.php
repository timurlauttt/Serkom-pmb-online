<?php $__env->startSection('title', 'SMK TAMAN SISWA PURWOKERTO - Modern & Berkarakter'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1 class="mobile:text-3xl">Membangun Generasi <br><span style="color: var(--primary-blue-hover);">Unggul & Kompeten</span></h1>
            <p class="mobile:text-base">Selamat datang di SMK Taman Siswa Purwokerto. Sekolah kejuruan berbasis teknologi dan industri dengan fasilitas modern untuk masa depan yang cerah.</p>
            <div style="display: flex; gap: 1rem;">
                <a href="#jurusan" class="btn btn-primary">Lihat Jurusan</a>
                <a href="<?php echo e(route('profilsekolah.profile')); ?>" class="btn btn-secondary">Tentang Kami</a>
            </div>
        </div>
    </div>
</section>

<!-- Jurusan Section -->
<section id="jurusan" class="section-padding">
    <div class="container">
        <h2 class="section-title mobile:text-xl">Program Keahlian</h2>
        <div class="news-grid">
            <?php $__empty_1 = true; $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- Card with Image -->
            <article class="news-card">
                <?php if($jurusan->image_url): ?>
                <img src="<?php echo e($jurusan->image_url); ?>" alt="<?php echo e($jurusan->name); ?>" class="news-img">
                <?php else: ?>
                <div class="news-img" style="background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-blue-hover) 100%); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-graduation-cap" style="font-size: 3rem; color: white;"></i>
                </div>
                <?php endif; ?>
                <div class="news-content">
                    <h3 class="news-title mobile:text-xl"><?php echo e($jurusan->name); ?></h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        <?php echo e(Str::limit(strip_tags($jurusan->description ?? ''), 100)); ?>

                    </p>
                    <a href="<?php echo e(route('jurusan.show', $jurusan->slug)); ?>" style="color: var(--primary-blue-hover); font-weight: 600;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <!-- Dummy Cards dengan foto -->
            <article class="news-card">
                <img src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Layanan Perbankan" class="news-img">
                <div class="news-content">
                    <h3 class="news-title mobile:text-xl">Layanan Perbankan</h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        Cetak ahli perbankan profesional dengan kurikulum standar industri terkini.
                    </p>
                    <a href="<?php echo e(route('jurusan.index')); ?>" style="color: var(--primary-blue-hover); font-weight: 600;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                </div>
            </article>
            <article class="news-card">
                <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Perhotelan" class="news-img">
                <div class="news-content">
                    <h3 class="news-title mobile:text-xl">Perhotelan</h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        Ahli hospitality dengan standar internasional yang siap kerja di industri perhotelan global.
                    </p>
                    <a href="<?php echo e(route('jurusan.index')); ?>" style="color: var(--primary-blue-hover); font-weight: 600;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                </div>
            </article>
            <article class="news-card">
                <img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Usaha Layanan Wisata" class="news-img">
                <div class="news-content">
                    <h3 class="news-title mobile:text-xl">Usaha Layanan Wisata</h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        Spesialis pariwisata dan travel agent untuk karir yang menjanjikan di industri wisata.
                    </p>
                    <a href="<?php echo e(route('jurusan.index')); ?>" style="color: var(--primary-blue-hover); font-weight: 600;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                </div>
            </article>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Mitra Section -->
<section class="partners">
    <div class="container">
        <p style="text-align: center; margin-bottom: 2rem; color: var(--accent-green-hover); font-weight: 600;">MITRA INDUSTRI KAMI</p>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; gap: 3rem;">
            <?php $__empty_1 = true; $__currentLoopData = $mitraList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="opacity: 0.8; transition: opacity 0.3s;">
                <?php if(isset($mitra->logo) || isset($mitra['logo'])): ?>
                <img src="<?php echo e($mitra->logo ?? $mitra['logo'] ?? asset('images/default-logo.png')); ?>"
                    alt="<?php echo e($mitra->nama ?? $mitra['name'] ?? 'Mitra'); ?>"
                    style="height: 60px; width: auto; object-fit: contain;"
                    onmouseover="this.parentElement.style.opacity='1'"
                    onmouseout="this.parentElement.style.opacity='0.8'">
                <?php else: ?>
                <div class="partner-logo"><?php echo e(strtoupper($mitra->nama ?? $mitra['name'] ?? 'MITRA')); ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <!-- Dummy logos dengan text -->
            <div class="partner-logo" style="opacity: 0.6;">PT. ASTRA HONDA</div>
            <div class="partner-logo" style="opacity: 0.6;">TELKOM INDONESIA</div>
            <div class="partner-logo" style="opacity: 0.6;">GAMELAB.ID</div>
            <div class="partner-logo" style="opacity: 0.6;">MITSUBISHI MOTORS</div>
            <div class="partner-logo" style="opacity: 0.6;">BANK BRI</div>
            <?php endif; ?>
        </div>
    </div>
</section>



<!-- Berita Terbaru Section -->
<section class="section-padding">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: end; margin-bottom: 2rem;">
            <h2 class="section-title mobile:text-xl" style="margin-bottom: 0;">Berita Terbaru</h2>
            <a href="<?php echo e(route('berita.index')); ?>" style="color: var(--text-muted);">Lihat Semua <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="news-grid">
            <?php $__empty_1 = true; $__currentLoopData = $beritas->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="news-card">
                <img src="<?php echo e($berita->image_url ?? 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'); ?>" alt="News" class="news-img">
                <div class="news-content">
                    <span class="news-meta mobile:text-xs"><?php echo e(optional($berita->created_at)->locale('id')->translatedFormat('d F Y') ?? 'BERITA TERBARU'); ?></span>
                    <h3 class="news-title mobile:text-lg"><?php echo e($berita->title); ?></h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        <?php echo e(Str::limit(strip_tags($berita->content ?? ''), 100)); ?>

                    </p>
                    <a href="<?php echo e(route('berita.show', $berita->slug)); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--accent-green-hover);">Baca Selengkapnya</a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <article class="news-card">
                <img src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="News" class="news-img">
                <div class="news-content">
                    <span class="news-meta mobile:text-xs">BERITA TERBARU</span>
                    <h3 class="news-title mobile:text-xl">Informasi Terbaru Akan Segera Hadir</h3>
                    <a href="<?php echo e(route('berita.index')); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--accent-green-hover);">Baca Selengkapnya</a>
                </div>
            </article>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Event Terbaru Section -->
<section class="section-padding" style="background-color: var(--bg-secondary);">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: end; margin-bottom: 2rem;">
            <h2 class="section-title mobile:text-xl" style="margin-bottom: 0;">Event Terbaru</h2>
            <a href="<?php echo e(route('event.index')); ?>" style="color: var(--text-muted);">Lihat Semua <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="news-grid">
            <?php $__empty_1 = true; $__currentLoopData = $eventsList->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="news-card">
                <img src="<?php echo e($event->image_url ?? 'https://images.unsplash.com/photo-1544531586-fde5298cdd40?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'); ?>" alt="Event" class="news-img">
                <div class="news-content">
                    <span class="news-meta mobile:text-xs" style="color: var(--highlight-yellow-hover);"><?php echo e(optional($event->start_date)->locale('id')->translatedFormat('d F Y') ?? 'EVENT TERBARU'); ?></span>
                    <h3 class="news-title mobile:text-lg"><?php echo e($event->title); ?></h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        <?php echo e(Str::limit(strip_tags($event->content ?? $event->description ?? ''), 100)); ?>

                    </p>
                    <a href="<?php echo e(route('event.show', $event->slug)); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--highlight-yellow-hover);">Lihat Detail</a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <article class="news-card">
                <img src="https://images.unsplash.com/photo-1544531586-fde5298cdd40?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="Event" class="news-img">
                <div class="news-content">
                    <span class="news-meta mobile:text-xs" style="color: var(--highlight-yellow-hover);">EVENT TERBARU</span>
                    <h3 class="news-title mobile:text-xl">Event Menarik Akan Segera Dilaksanakan</h3>
                    <a href="<?php echo e(route('event.index')); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--highlight-yellow-hover);">Lihat Detail</a>
                </div>
            </article>
            <?php endif; ?>
        </div>
    </div>
</section>



<!-- Pengumuman Terbaru Section -->
<section class="section-padding">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: end; margin-bottom: 2rem;">
            <h2 class="section-title mobile:text-xl" style="margin-bottom: 0;">Pengumuman Terbaru</h2>
            <a href="<?php echo e(route('pengumuman.index')); ?>" style="color: var(--text-muted);">Lihat Semua <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="news-grid">
            <?php $__empty_1 = true; $__currentLoopData = $announcements->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="news-card">
                <?php if($pengumuman->image_url): ?>
                <img src="<?php echo e($pengumuman->image_url); ?>" alt="Pengumuman" class="news-img">
                <?php else: ?>
                <div class="news-img" style="background: var(--bg-secondary); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-blue-hover);"></i>
                </div>
                <?php endif; ?>
                <div class="news-content">
                    <span class="news-meta mobile:text-xs" style="color: var(--primary-blue-hover);"><?php echo e(optional($pengumuman->posted_at)->locale('id')->translatedFormat('d F Y') ?? 'PENGUMUMAN'); ?></span>
                    <h3 class="news-title mobile:text-lg"><?php echo e($pengumuman->title); ?></h3>
                    <p class="mobile:text-sm" style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                        <?php echo e(Str::limit(strip_tags($pengumuman->content ?? ''), 100)); ?>

                    </p>
                    <a href="<?php echo e(route('pengumuman.show', $pengumuman->slug)); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--primary-blue-hover);">Lihat Detail</a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <article class="news-card">
                <div class="news-img" style="background: var(--bg-secondary); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-blue-hover);"></i>
                </div>
                <div class="news-content">
                    <span class="news-meta mobile:text-xs" style="color: var(--primary-blue-hover);">PENGUMUMAN PENTING</span>
                    <h3 class="news-title mobile:text-xl">Pengumuman Penting Akan Diumumkan</h3>
                    <a href="<?php echo e(route('pengumuman.index')); ?>" class="btn-link" style="font-size: 0.9rem; color: var(--primary-blue-hover);">Lihat Detail</a>
                </div>
            </article>
            <?php endif; ?>
        </div>
    </div>
</section>


<!-- Galeri Section -->
<section class="section-padding" style="background-color: var(--bg-secondary);">
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: end; margin-bottom: 2rem;">
            <h2 class="section-title mobile:text-xl" style="margin-bottom: 0;">Galeri Sekolah</h2>
            <a href="<?php echo e(route('galeri.index')); ?>" style="color: var(--text-muted);">Lihat Semua <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="news-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
            <?php $__empty_1 = true; $__currentLoopData = $galleryList->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <img src="<?php echo e(asset($gallery->path) ?? 'https://images.unsplash.com/photo-1577896333050-7f287902728f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60'); ?>"
                style="border-radius: var(--border-radius); height: 200px; width: 100%; object-fit: cover;"
                alt="<?php echo e($gallery->title ?? 'Gallery'); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <img src="https://images.unsplash.com/photo-1577896333050-7f287902728f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60" style="border-radius: var(--border-radius); height: 200px; width: 100%; object-fit: cover;" alt="Gallery 1">
            <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60" style="border-radius: var(--border-radius); height: 200px; width: 100%; object-fit: cover;" alt="Gallery 2">
            <img src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60" style="border-radius: var(--border-radius); height: 200px; width: 100%; object-fit: cover;" alt="Gallery 3">
            <img src="https://images.unsplash.com/photo-1588072432836-e10032774350?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=60" style="border-radius: var(--border-radius); height: 200px; width: 100%; object-fit: cover;" alt="Gallery 4">
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\welcome.blade.php ENDPATH**/ ?>