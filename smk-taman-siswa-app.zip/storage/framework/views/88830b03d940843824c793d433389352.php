<?php $__env->startSection('title', 'Detail Objek Wisata'); ?>
<?php $__env->startSection('page-title', 'Detail Objek Wisata'); ?>
<?php $__env->startSection('page-description', 'Lihat detail objek wisata'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-6 space-y-4">
            <?php if($objekWisata->gambar): ?>
            <div>
                <img src="<?php echo e(asset($objekWisata->gambar)); ?>" alt="Foto Objek Wisata" class="w-full h-48 object-cover rounded mb-4">
            </div>
            <?php endif; ?>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Nama</span>
                <div class="font-semibold text-gray-800"><?php echo e($objekWisata->nama); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Alamat</span>
                <div class="text-gray-700"><?php echo e($objekWisata->alamat); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Kota</span>
                <div class="text-gray-700"><?php echo e($objekWisata->kota); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Harga Tiket</span>
                <div class="text-gray-700"><?php echo e($objekWisata->harga_tiket ? 'Rp ' . number_format($objekWisata->harga_tiket,0,',','.') : '-'); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Jam Operasional</span>
                <div class="text-gray-700"><?php echo e($objekWisata->jam_operasional ?? '-'); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Slug</span>
                <div class="text-xs text-gray-500 font-mono"><?php echo e($objekWisata->slug); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Deskripsi</span>
                <div class="text-gray-700"><?php echo e($objekWisata->deskripsi); ?></div>
            </div>
        </div>
        <div class="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
            <a href="<?php echo e(route('admin.objek-wisata.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-gray-700 hover:bg-gray-300">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\objek-wisata\show.blade.php ENDPATH**/ ?>