
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => '',
    'subtitle' => null,
    'breadcrumbs' => [],
    'backgroundImage' => null,
    'overlay' => true
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => '',
    'subtitle' => null,
    'breadcrumbs' => [],
    'backgroundImage' => null,
    'overlay' => true
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="pt-150 pb-20 <?php if($backgroundImage): ?> bg-img <?php endif; ?>" 
         <?php if($backgroundImage): ?> style="background-image: url('<?php echo e($backgroundImage); ?>')" <?php endif; ?>>
    <?php if($backgroundImage && $overlay): ?>
        <div class="overlay" style="background: rgba(0,0,0,0.5);"></div>
    <?php endif; ?>
    
    <div class="container" style="position: relative; z-index: 1;">
        <div class="row">
            <div class="col-12">
                <div class="text-center">
                    <?php if(count($breadcrumbs) > 0): ?>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center bg-transparent">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('landingpage')); ?>" class="<?php if($backgroundImage): ?> text-white <?php endif; ?>">Home</a></li>
                                <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->last): ?>
                                        <li class="breadcrumb-item active <?php if($backgroundImage): ?> text-white <?php endif; ?>" aria-current="page"><?php echo e($crumb['title']); ?></li>
                                    <?php else: ?>
                                        <li class="breadcrumb-item">
                                            <a href="<?php echo e($crumb['url']); ?>" class="<?php if($backgroundImage): ?> text-white <?php endif; ?>"><?php echo e($crumb['title']); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </nav>
                    <?php endif; ?>
                    
                    <h2 class="page-title <?php if($backgroundImage): ?> text-white <?php else: ?> text-black <?php endif; ?>"><?php echo e($title); ?></h2>
                    
                    <?php if($subtitle): ?>
                        <p class="<?php if($backgroundImage): ?> text-white-50 <?php else: ?> text-muted <?php endif; ?> fs-16 mt-10"><?php echo e($subtitle); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\components\page-header.blade.php ENDPATH**/ ?>