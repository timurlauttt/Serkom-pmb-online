<?php $__env->startSection('title', 'Link PPDB'); ?>
<?php $__env->startSection('page-title', 'Manajemen Link PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h3 class="text-2xl font-bold text-gray-800">Daftar Link PPDB</h3>
        <a href="<?php echo e(route('admin.ppdb_links.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i>Tambah Link
        </a>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <?php if($links->count() > 0): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Nama Link</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">URL</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Jenis</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Order</th>
                        <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($link->nama_link); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e(Str::limit($link->deskripsi, 50)); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <a href="<?php echo e($link->url); ?>" target="_blank" class="text-blue-600 hover:text-blue-800 text-sm">
                                <i class="fas fa-external-link-alt mr-1"></i><?php echo e(Str::limit($link->url, 40)); ?>

                            </a>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded
                                <?php echo e($link->jenis === 'pendaftaran' ? 'bg-green-100 text-green-800' : ''); ?>

                                <?php echo e($link->jenis === 'info' ? 'bg-blue-100 text-blue-800' : ''); ?>

                                <?php echo e($link->jenis === 'hasil' ? 'bg-purple-100 text-purple-800' : ''); ?>

                                <?php echo e($link->jenis === 'lainnya' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                <?php echo e(ucfirst($link->jenis)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs rounded <?php echo e($link->is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                                <?php echo e($link->is_active ? 'Aktif' : 'Nonaktif'); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm"><?php echo e($link->order); ?></td>
                        <td class="px-6 py-4">
                            <div class="flex space-x-2">
                                <a href="<?php echo e(route('admin.ppdb_links.edit', $link->id)); ?>" class="text-yellow-600 hover:text-yellow-800"><i class="fas fa-edit"></i></a>
                                <form action="<?php echo e(route('admin.ppdb_links.destroy', $link->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus link ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-link text-gray-300 text-5xl mb-4"></i>
                <p class="text-gray-500">Belum ada link PPDB</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\admin\ppdb\links\index.blade.php ENDPATH**/ ?>