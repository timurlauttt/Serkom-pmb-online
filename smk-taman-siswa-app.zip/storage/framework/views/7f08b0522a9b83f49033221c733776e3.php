<?php $__env->startSection('title', 'Detail Profile Sekolah'); ?>
<?php $__env->startSection('page-title', 'Detail Profile Sekolah'); ?>
<?php $__env->startSection('page-description', 'Informasi lengkap profile sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-8 space-y-8">
            <!-- Vision -->
            <div class="pb-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-eye text-purple-500 mr-3"></i>
                    Visi Sekolah
                </h2>
                <p class="text-gray-700 leading-relaxed bg-purple-50 p-4 rounded-lg">
                    <?php echo e($profile->vision); ?>

                </p>
            </div>

            <!-- Mission -->
            <div class="pb-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-bullseye text-pink-500 mr-3"></i>
                    Misi Sekolah
                </h2>
                <?php if(is_array($profile->mission) && count($profile->mission) > 0): ?>
                    <ol class="space-y-2">
                        <?php $__currentLoopData = $profile->mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-start bg-pink-50 p-3 rounded-lg">
                                <span class="flex-shrink-0 w-6 h-6 bg-pink-500 text-white rounded-full flex items-center justify-center text-xs font-semibold mr-3 mt-0.5">
                                    <?php echo e($loop->iteration); ?>

                                </span>
                                <span class="text-gray-700 flex-1"><?php echo e($item); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                <?php else: ?>
                    <p class="text-gray-700 leading-relaxed bg-pink-50 p-4 rounded-lg">
                        <?php echo e($profile->mission); ?>

                    </p>
                <?php endif; ?>
            </div>

            <!-- History -->
            <div class="pb-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-history text-blue-500 mr-3"></i>
                    Sejarah Sekolah
                </h2>
                <p class="text-gray-700 leading-relaxed whitespace-pre-line bg-blue-50 p-4 rounded-lg">
                    <?php echo e($profile->history); ?>

                </p>
            </div>

            <!-- Facilities -->
            <div class="pb-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-building text-green-500 mr-3"></i>
                    Fasilitas Sekolah
                </h2>
                <?php if(is_array($profile->facilities) && count($profile->facilities) > 0): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php $__currentLoopData = $profile->facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if (is_array($facility)) {
                                    $facilityName = $facility['name'] ?? '';
                                } elseif (is_object($facility)) {
                                    $facilityName = $facility->name ?? '';
                                } else {
                                    $facilityName = $facility;
                                }
                            ?>
                            <div class="flex items-center bg-green-50 p-3 rounded-lg">
                                <i class="fas fa-check-circle text-green-500 mr-3"></i>
                                <span class="text-gray-700"><?php echo e($facilityName); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-700 leading-relaxed bg-green-50 p-4 rounded-lg">
                        <?php echo e($profile->facilities); ?>

                    </p>
                <?php endif; ?>
            </div>

            <!-- Accreditation -->
            <div class="pb-6 border-b border-gray-100">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                    <i class="fas fa-certificate text-yellow-500 mr-3"></i>
                    Akreditasi
                </h2>
                <div class="inline-flex items-center bg-yellow-100 text-yellow-800 px-6 py-3 rounded-lg font-bold text-2xl">
                    <?php echo e($profile->accreditation); ?>

                    <?php if($profile->accreditation == 'A'): ?>
                        <span class="ml-2 text-base font-normal">(Unggul)</span>
                    <?php elseif($profile->accreditation == 'B'): ?>
                        <span class="ml-2 text-base font-normal">(Baik)</span>
                    <?php elseif($profile->accreditation == 'C'): ?>
                        <span class="ml-2 text-base font-normal">(Cukup)</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Organization Chart -->
            <?php if($profile->org_chart_path): ?>
                <div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                        <i class="fas fa-sitemap text-indigo-500 mr-3"></i>
                        Struktur Organisasi
                    </h2>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <img src="<?php echo e(asset('storage/' . $profile->org_chart_path)); ?>" alt="Organization Chart" class="w-full rounded-lg shadow-md">
                    </div>
                </div>
            <?php endif; ?>

            <!-- Meta Info -->
            <div class="pt-6 border-t border-gray-100 grid grid-cols-2 gap-4 text-sm">
                <div>
                    <span class="text-gray-500">Dibuat:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($profile->created_at->format('d M Y H:i')); ?></span>
                </div>
                <div>
                    <span class="text-gray-500">Terakhir diupdate:</span>
                    <span class="text-gray-900 ml-2"><?php echo e($profile->updated_at->format('d M Y H:i')); ?></span>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="bg-gray-50 px-8 py-4 flex justify-between items-center border-t border-gray-100">
            <a href="<?php echo e(route('admin.profiles.index')); ?>" class="px-4 py-2 text-gray-700 hover:text-gray-900 font-medium">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('admin.profiles.edit', $profile->id)); ?>" class="px-4 py-2 bg-yellow-50 text-yellow-600 rounded-lg hover:bg-yellow-100 transition-colors font-medium">
                    <i class="fas fa-edit mr-2"></i>Edit
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\profiles\show.blade.php ENDPATH**/ ?>