<?php $__env->startSection('title', 'Detail Transportasi'); ?>
<?php $__env->startSection('page-title', 'Detail Transportasi'); ?>
<?php $__env->startSection('page-description', 'Informasi lengkap transportasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-6 space-y-6">
            <?php if($transportasi->gambar): ?>
                <div>
                    <img src="<?php echo e(asset($transportasi->gambar)); ?>" alt="Gambar Transportasi" class="w-full h-64 object-cover rounded-lg">
                </div>
            <?php endif; ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Jenis Transportasi</label>
                    <p class="text-gray-900 font-medium"><?php echo e($transportasi->jenis); ?></p>
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Nama Provider</label>
                    <p class="text-gray-900 font-medium"><?php echo e($transportasi->nama_provider); ?></p>
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Harga</label>
                    <p class="text-gray-900 font-medium">Rp <?php echo e(number_format($transportasi->harga, 0, ',', '.')); ?></p>
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Kontak</label>
                    <p class="text-gray-900 font-medium"><?php echo e($transportasi->kontak ?? '-'); ?></p>
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Slug</label>
                    <p class="text-gray-900 font-medium"><?php echo e($transportasi->slug); ?></p>
                </div>
            </div>
        </div>
        <div class="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
            <a href="<?php echo e(route('admin.transportasi.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-gray-700 hover:bg-gray-300">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center">
                <a href="<?php echo e(route('admin.transportasi.index')); ?>" class="text-gray-600 hover:text-gray-800 mr-4">
                    <i class="fas fa-arrow-left text-xl"></i>
                </a>
                <h1 class="text-3xl font-bold text-gray-800">Detail Transportasi</h1>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('admin.transportasi.edit', $transportasi->slug)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg transition duration-300">
                    <i class="fas fa-edit mr-2"></i>Edit
                </a>
                <form action="<?php echo e(route('admin.transportasi.destroy', $transportasi->slug)); ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus transportasi ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition duration-300">
                        <i class="fas fa-trash mr-2"></i>Hapus
                    </button>
                </form>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <?php if($transportasi->gambar): ?>
                <div class="w-full h-96 overflow-hidden">
                    <img src="<?php echo e(asset($transportasi->gambar)); ?>" alt="<?php echo e($transportasi->nama_provider); ?>" class="w-full h-full object-cover">
                </div>
            <?php endif; ?>

            <div class="p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="mb-4">
                        <h3 class="text-sm font-semibold text-gray-600 uppercase mb-2">Jenis Transportasi</h3>
                        <p class="text-lg text-gray-900"><?php echo e($transportasi->jenis); ?></p>
                    </div>

                    <div class="mb-4">
                        <h3 class="text-sm font-semibold text-gray-600 uppercase mb-2">Nama Provider</h3>
                        <p class="text-lg text-gray-900"><?php echo e($transportasi->nama_provider); ?></p>
                    </div>

                    <div class="mb-4">
                        <h3 class="text-sm font-semibold text-gray-600 uppercase mb-2">Harga</h3>
                        <p class="text-lg text-gray-900">Rp <?php echo e(number_format($transportasi->harga, 0, ',', '.')); ?></p>
                    </div>

                    <div class="mb-4">
                        <h3 class="text-sm font-semibold text-gray-600 uppercase mb-2">Kontak</h3>
                        <p class="text-lg text-gray-900"><?php echo e($transportasi->kontak); ?></p>
                    </div>
                </div>

                <div class="mt-8 pt-6 border-t border-gray-200">
                    <div class="flex justify-between text-sm text-gray-600">
                        <div>
                            <span class="font-semibold">Dibuat:</span> <?php echo e($transportasi->created_at->format('d M Y H:i')); ?>

                        </div>
                        <div>
                            <span class="font-semibold">Diperbarui:</span> <?php echo e($transportasi->updated_at->format('d M Y H:i')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\transportasi\show.blade.php ENDPATH**/ ?>