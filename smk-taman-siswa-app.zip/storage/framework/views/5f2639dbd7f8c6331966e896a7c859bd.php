<?php $__env->startSection('title', 'Struktur Organisasi - SMK Taman Siswa Purwokerto'); ?>

<?php $__env->startSection('content'); ?>


<?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'STRUKTUR ORGANISASI','subtitle' => 'Kepemimpinan dan tim pengajar yang berdedikasi','breadcrumbs' => [
        ['title' => 'Profil', 'url' => '#'],
        ['title' => 'Struktur Organisasi', 'url' => route('profilsekolah.struktur_organisasi')]
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'STRUKTUR ORGANISASI','subtitle' => 'Kepemimpinan dan tim pengajar yang berdedikasi','breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['title' => 'Profil', 'url' => '#'],
        ['title' => 'Struktur Organisasi', 'url' => route('profilsekolah.struktur_organisasi')]
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

<section class="section">
    <div class="container">
        
        <div style="max-width: 1000px; margin: 0 auto;">
            
            
            <div style="text-align: center; margin-bottom: 3rem;">
                <div style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2rem; border-radius: 1rem; box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3); min-width: 300px;">
                    <i class="fas fa-user-tie" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                    <h4 style="margin: 0 0 0.5rem 0; color: white;">Kepala Sekolah</h4>
                    <p style="margin: 0; opacity: 0.9; font-size: 1.1rem;">Drs. [Nama Kepala Sekolah]</p>
                    <p style="margin: 0.5rem 0 0 0; opacity: 0.8; font-size: 0.9rem;">NIP: [NIP]</p>
                </div>
            </div>

            
            <div style="height: 40px; display: flex; justify-content: center;">
                <div style="width: 2px; height: 100%; background: #667eea;"></div>
            </div>

            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
                
                
                <div style="background: white; padding: 1.5rem; border-radius: 1rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-top: 4px solid #667eea;">
                    <div style="text-align: center;">
                        <i class="fas fa-user-graduate" style="font-size: 2.5rem; color: #667eea; margin-bottom: 1rem;"></i>
                        <h5 style="margin: 0 0 0.5rem 0; color: #333;">Wakil Kepala Sekolah</h5>
                        <p style="margin: 0; color: #666; font-size: 0.95rem;">[Nama Wakasek]</p>
                        <p style="margin: 0.25rem 0 0 0; color: #999; font-size: 0.85rem;">NIP: [NIP]</p>
                    </div>
                </div>

                
                <div style="background: white; padding: 1.5rem; border-radius: 1rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-top: 4px solid #f093fb;">
                    <div style="text-align: center;">
                        <i class="fas fa-users" style="font-size: 2.5rem; color: #f093fb; margin-bottom: 1rem;"></i>
                        <h5 style="margin: 0 0 0.5rem 0; color: #333;">Komite Sekolah</h5>
                        <p style="margin: 0; color: #666; font-size: 0.95rem;">[Nama Ketua Komite]</p>
                        <p style="margin: 0.25rem 0 0 0; color: #999; font-size: 0.85rem;">Ketua</p>
                    </div>
                </div>

            </div>

            
            <div style="height: 40px; display: flex; justify-content: center;">
                <div style="width: 2px; height: 100%; background: #667eea;"></div>
            </div>

            
            <h4 style="text-align: center; margin: 2rem 0; color: #333;">Tim Manajemen</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 3rem;">
                
                
                <div style="background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #667eea;">
                    <i class="fas fa-book" style="font-size: 2rem; color: #667eea; margin-bottom: 0.75rem;"></i>
                    <h6 style="margin: 0 0 0.5rem 0; color: #333;">Urusan Kurikulum</h6>
                    <p style="margin: 0; color: #666; font-size: 0.9rem;">[Nama]</p>
                </div>

                
                <div style="background: linear-gradient(135deg, rgba(240, 147, 251, 0.1) 0%, rgba(245, 87, 108, 0.1) 100%); padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #f093fb;">
                    <i class="fas fa-user-friends" style="font-size: 2rem; color: #f093fb; margin-bottom: 0.75rem;"></i>
                    <h6 style="margin: 0 0 0.5rem 0; color: #333;">Urusan Kesiswaan</h6>
                    <p style="margin: 0; color: #666; font-size: 0.9rem;">[Nama]</p>
                </div>

                
                <div style="background: linear-gradient(135deg, rgba(79, 172, 254, 0.1) 0%, rgba(0, 242, 254, 0.1) 100%); padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #4facfe;">
                    <i class="fas fa-tools" style="font-size: 2rem; color: #4facfe; margin-bottom: 0.75rem;"></i>
                    <h6 style="margin: 0 0 0.5rem 0; color: #333;">Urusan Sarana Prasarana</h6>
                    <p style="margin: 0; color: #666; font-size: 0.9rem;">[Nama]</p>
                </div>

                
                <div style="background: linear-gradient(135deg, rgba(250, 112, 154, 0.1) 0%, rgba(254, 225, 64, 0.1) 100%); padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #fa709a;">
                    <i class="fas fa-handshake" style="font-size: 2rem; color: #fa709a; margin-bottom: 0.75rem;"></i>
                    <h6 style="margin: 0 0 0.5rem 0; color: #333;">Urusan Humas</h6>
                    <p style="margin: 0; color: #666; font-size: 0.9rem;">[Nama]</p>
                </div>

            </div>

            
            <div style="background: #f8f9fa; padding: 2rem; border-radius: 1rem; margin-bottom: 2rem;">
                <h4 style="text-align: center; margin: 0 0 2rem 0; color: #333;">Tim Pengajar & Tenaga Kependidikan</h4>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem;">
                    
                    
                    <div style="text-align: center; padding: 1rem;">
                        <div style="width: 60px; height: 60px; background: #667eea; border-radius: 50%; margin: 0 auto 0.75rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-chalkboard-teacher" style="font-size: 1.5rem; color: white;"></i>
                        </div>
                        <h6 style="margin: 0 0 0.25rem 0; color: #333;">Guru Produktif</h6>
                        <p style="margin: 0; color: #666; font-size: 0.85rem;">8 Orang</p>
                    </div>

                    
                    <div style="text-align: center; padding: 1rem;">
                        <div style="width: 60px; height: 60px; background: #f093fb; border-radius: 50%; margin: 0 auto 0.75rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-book-reader" style="font-size: 1.5rem; color: white;"></i>
                        </div>
                        <h6 style="margin: 0 0 0.25rem 0; color: #333;">Guru Normatif</h6>
                        <p style="margin: 0; color: #666; font-size: 0.85rem;">5 Orang</p>
                    </div>

                    
                    <div style="text-align: center; padding: 1rem;">
                        <div style="width: 60px; height: 60px; background: #4facfe; border-radius: 50%; margin: 0 auto 0.75rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-file-alt" style="font-size: 1.5rem; color: white;"></i>
                        </div>
                        <h6 style="margin: 0 0 0.25rem 0; color: #333;">Staff Tata Usaha</h6>
                        <p style="margin: 0; color: #666; font-size: 0.85rem;">3 Orang</p>
                    </div>

                </div>
            </div>

            
            <div style="background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); padding: 1.5rem; border-radius: 0.75rem; border-left: 4px solid #667eea; text-align: center;">
                <i class="fas fa-info-circle" style="color: #667eea; font-size: 1.5rem; margin-bottom: 0.5rem;"></i>
                <p style="margin: 0; color: #666;">
                    Struktur organisasi dapat berubah sesuai dengan kebutuhan dan perkembangan sekolah. 
                    Untuk informasi lebih detail hubungi bagian Tata Usaha.
                </p>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    @media (max-width: 768px) {
        .container > div > div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('utama.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\struktur-organisasi.blade.php ENDPATH**/ ?>