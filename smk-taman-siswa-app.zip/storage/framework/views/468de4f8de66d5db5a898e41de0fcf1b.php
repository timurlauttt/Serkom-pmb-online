
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => '',
    'slug' => '',
    'route' => '',
    'image' => null,
    'author' => null,
    'date' => null,
    'category' => null,
    'excerpt' => '',
    'horizontal' => false,
    'readMoreText' => 'Selengkapnya'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => '',
    'slug' => '',
    'route' => '',
    'image' => null,
    'author' => null,
    'date' => null,
    'category' => null,
    'excerpt' => '',
    'horizontal' => false,
    'readMoreText' => 'Selengkapnya'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($horizontal): ?>
    
    <div <?php echo e($attributes->merge(['class' => 'box mb-20'])); ?>>
        <div class="row g-0">
            <div class="col-md-4 col-12 bg-img h-md-auto h-250" 
                 <?php if($image): ?> style="background-image: url('<?php echo e($image); ?>')" <?php endif; ?>>
            </div>
            <div class="col-md-8 col-12">
                <div class="box-body">
                    <?php if($category): ?>
                        <span class="badge badge-primary mb-10"><?php echo e($category); ?></span>
                    <?php endif; ?>
                    
                    <h4>
                        <a href="<?php echo e($route); ?>"><?php echo e($title); ?></a>
                    </h4>
                    
                    <?php if($author || $date): ?>
                        <div class="d-flex mb-10">
                            <?php if($author): ?>
                                <div class="me-10">
                                    <i class="fa fa-user me-5"></i> <?php echo e($author); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($date): ?>
                                <div>
                                    <i class="fa fa-calendar me-5"></i> <?php echo e($date); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <p><?php echo e($excerpt); ?></p>

                    <div class="flexbox align-items-center mt-3">
                        <a class="btn btn-sm btn-primary" href="<?php echo e($route); ?>"><?php echo e($readMoreText); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    
    <div <?php echo e($attributes->merge(['class' => 'box'])); ?>>
        <?php if($image): ?>
            <div class="box-header with-border p-0">
                <img src="<?php echo e($image); ?>" class="img-fluid" alt="<?php echo e($title); ?>" style="width: 100%; height: 200px; object-fit: cover;">
            </div>
        <?php endif; ?>
        
        <div class="box-body">
            <?php if($category): ?>
                <span class="badge badge-primary mb-10"><?php echo e($category); ?></span>
            <?php endif; ?>
            
            <h4 class="box-title">
                <a href="<?php echo e($route); ?>"><?php echo e($title); ?></a>
            </h4>
            
            <?php if($author || $date): ?>
                <div class="d-flex mb-10 text-muted fs-14">
                    <?php if($author): ?>
                        <div class="me-10">
                            <i class="fa fa-user me-5"></i> <?php echo e($author); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($date): ?>
                        <div>
                            <i class="fa fa-calendar me-5"></i> <?php echo e($date); ?>

                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <p><?php echo e($excerpt); ?></p>
        </div>
        
        <div class="box-footer">
            <a href="<?php echo e($route); ?>" class="btn btn-sm btn-primary"><?php echo e($readMoreText); ?></a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\components\card.blade.php ENDPATH**/ ?>