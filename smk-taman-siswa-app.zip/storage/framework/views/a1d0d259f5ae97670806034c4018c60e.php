<?php if(isset($paketWisataList) && $paketWisataList->count() > 0): ?>
    <div class="category-section" style="margin-bottom: 5rem;">
        <div
            style="display: flex; align-items: center; gap: 1rem; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 3px solid var(--highlight-yellow);">
            <i class="fas fa-suitcase" style="font-size: 1.75rem; color: var(--highlight-yellow);"></i>
            <h3 style="font-size: 1.75rem; font-weight: 700; color: var(--text-main); margin: 0;">Paket Wisata</h3>
            <span
                style="background: var(--highlight-yellow); color: white; padding: 0.25rem 0.75rem; border-radius: 2rem; font-size: 0.875rem; font-weight: 600;">
                <?php echo e($paketWisataList->count()); ?> Paket
            </span>
        </div>

        <div class="news-grid"
            style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem;">
            <?php $__currentLoopData = $paketWisataList->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="news-card search-item" data-category="paket"
                    data-title="<?php echo e(strtolower($pw->nama_paket)); ?>"
                    data-desc="<?php echo e(strtolower(strip_tags($pw->keterangan ?? ''))); ?>">
                    <img src="<?php echo e($resolveImage($pw)); ?>" alt="<?php echo e($pw->nama_paket); ?>" class="news-img">
                    <div class="news-content">
                        <div
                            style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem; flex-wrap: wrap;">
                            <?php if($pw->kategori): ?>
                                <span
                                    style="background: var(--primary-blue); color: white; padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 600;">
                                    <i class="fas fa-tag"></i> <?php echo e($pw->kategori); ?>

                                </span>
                            <?php endif; ?>
                            <span class="news-meta"
                                style="color: var(--highlight-yellow-hover);"><?php echo e($pw->durasi_hari ? $pw->durasi_hari . ' Hari' : '-'); ?></span>
                        </div>
                        <h3 class="news-title"><?php echo e($pw->nama_paket); ?></h3>
                        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                            <?php echo e(Str::limit(strip_tags($pw->keterangan), 80)); ?>

                        </p>
                        <a href="<?php echo e(route('paket-wisata-detail', ['slug' => $pw->slug])); ?>" class="btn-link"
                            style="color: var(--highlight-yellow-hover);">Detail Paket <i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($paketWisataList->count() > 8): ?>
            <div class="hidden-items-paket" style="display: none;">
                <div class="news-grid"
                    style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; margin-top: 1.5rem;">
                    <?php $__currentLoopData = $paketWisataList->skip(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="news-card search-item" data-category="paket"
                            data-title="<?php echo e(strtolower($pw->nama_paket)); ?>"
                            data-desc="<?php echo e(strtolower(strip_tags($pw->keterangan ?? ''))); ?>">
                            <img src="<?php echo e($resolveImage($pw)); ?>" alt="<?php echo e($pw->nama_paket); ?>" class="news-img">
                            <div class="news-content">
                                <div
                                    style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem; flex-wrap: wrap;">
                                    <?php if($pw->kategori): ?>
                                        <span
                                            style="background: var(--primary-blue); color: white; padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.75rem; font-weight: 600;">
                                            <i class="fas fa-tag"></i> <?php echo e($pw->kategori); ?>

                                        </span>
                                    <?php endif; ?>
                                    <span class="news-meta"
                                        style="color: var(--highlight-yellow-hover);"><?php echo e($pw->durasi_hari ? $pw->durasi_hari . ' Hari' : '-'); ?></span>
                                </div>
                                <h3 class="news-title"><?php echo e($pw->nama_paket); ?></h3>
                                <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                                    <?php echo e(Str::limit(strip_tags($pw->keterangan), 80)); ?>

                                </p>
                                <a href="<?php echo e(route('paket-wisata-detail', $pw->slug)); ?>" class="btn-link"
                                    style="color: var(--highlight-yellow-hover);">Detail Paket <i
                                        class="fas fa-arrow-right"></i></a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div style="text-align: center; margin-top: 2rem;">
                <button class="show-more-btn" data-target="hidden-items-paket"
                    style="padding: 0.875rem 2rem; background: var(--highlight-yellow); color: white; border: none; border-radius: 2rem; cursor: pointer; font-weight: 600; font-size: 1rem; transition: all 0.3s; display: inline-flex; align-items: center; gap: 0.5rem;">
                    <i class="fas fa-chevron-down"></i>
                    Tampilkan Lebih Banyak (<?php echo e($paketWisataList->count() - 8); ?> paket)
                </button>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\utama\content\tic\sections\paket.blade.php ENDPATH**/ ?>