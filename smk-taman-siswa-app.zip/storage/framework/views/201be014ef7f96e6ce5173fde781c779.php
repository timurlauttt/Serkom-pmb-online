<?php $__env->startSection('title', 'Edit Jalur PPDB'); ?>
<?php $__env->startSection('page-title', 'Edit Jalur PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
        <form action="<?php echo e(route('admin.ppdb_jalurs.update', $ppdbJalur->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="p-6 space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nama Jalur <span class="text-red-500">*</span></label>
                    <input type="text" name="nama_jalur" value="<?php echo e(old('nama_jalur', $ppdbJalur->nama_jalur)); ?>" class="w-full px-4 py-2 border rounded-lg" required>
                </div>
                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Mulai <span class="text-red-500">*</span></label>
                        <input type="date" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai', $ppdbJalur->tanggal_mulai->format('Y-m-d'))); ?>" class="w-full px-4 py-2 border rounded-lg" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Selesai <span class="text-red-500">*</span></label>
                        <input type="date" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai', $ppdbJalur->tanggal_selesai->format('Y-m-d'))); ?>" class="w-full px-4 py-2 border rounded-lg" required>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Kuota</label>
                        <input type="number" name="kuota" value="<?php echo e(old('kuota', $ppdbJalur->kuota)); ?>" class="w-full px-4 py-2 border rounded-lg" min="0">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Order</label>
                        <input type="number" name="order" value="<?php echo e(old('order', $ppdbJalur->order)); ?>" class="w-full px-4 py-2 border rounded-lg" min="0">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi <span class="text-red-500">*</span></label>
                    <textarea name="deskripsi" rows="4" class="w-full px-4 py-2 border rounded-lg" required><?php echo e(old('deskripsi', $ppdbJalur->deskripsi)); ?></textarea>
                </div>
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $ppdbJalur->is_active) ? 'checked' : ''); ?> class="rounded">
                        <span class="ml-2 text-sm">Aktif</span>
                    </label>
                </div>
            </div>
            <div class="bg-gray-50 px-6 py-4 flex justify-between border-t">
                <a href="<?php echo e(route('admin.ppdb_jalurs.index')); ?>" class="px-4 py-2 text-gray-700"><i class="fas fa-arrow-left mr-2"></i>Kembali</a>
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg"><i class="fas fa-save mr-2"></i>Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\admin\ppdb\jalurs\edit.blade.php ENDPATH**/ ?>