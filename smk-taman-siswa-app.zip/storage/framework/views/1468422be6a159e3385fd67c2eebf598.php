
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'showSearch' => true,
    'showCategories' => true,
    'showRecent' => true,
    'categories' => [],
    'recentPosts' => [],
    'categoryRoute' => 'berita.index',
    'postRoute' => 'berita.show'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'showSearch' => true,
    'showCategories' => true,
    'showRecent' => true,
    'categories' => [],
    'recentPosts' => [],
    'categoryRoute' => 'berita.index',
    'postRoute' => 'berita.show'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'side-block px-20 py-10 bg-white'])); ?>>
    
    <?php if($showSearch): ?>
        <div class="widget courses-search-bx placeholdertx mb-30">
            <form method="GET" action="<?php echo e(url()->current()); ?>">
                <div class="form-group">
                    <label class="form-label">Cari...</label>
                    <div class="input-group">
                        <input name="search" type="text" class="form-control" 
                               placeholder="Ketik kata kunci..." 
                               value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>

    
    <?php if($showCategories && count($categories) > 0): ?>
        <div class="widget clearfix mb-30">
            <h4 class="pb-15 mb-15 bb-1">Kategori</h4>
            <div class="media-list media-list-divided">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="px-0 media media-single" href="<?php echo e(route($categoryRoute, ['category' => $cat['name']])); ?>">
                        <span class="title ms-0"><?php echo e($cat['name']); ?></span>
                        <span class="mx-0 badge badge-secondary-light"><?php echo e($cat['count']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if($showRecent && count($recentPosts) > 0): ?>
        <div class="widget clearfix">
            <h4 class="pb-15 mb-25 bb-1">Terbaru</h4>
            <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="recent-post clearfix mb-20">
                    <?php if(isset($post['image']) && $post['image']): ?>
                        <div class="recent-post-image">
                            <img class="img-fluid bg-primary-light" 
                                 src="<?php echo e($post['image']); ?>" 
                                 alt="<?php echo e($post['title']); ?>">
                        </div>
                    <?php endif; ?>
                    <div class="recent-post-info">
                        <a href="<?php echo e(route($postRoute, $post['slug'])); ?>">
                            <?php echo e(\Illuminate\Support\Str::limit($post['title'], 60)); ?>

                        </a>
                        <?php if(isset($post['date']) && $post['date']): ?>
                            <span>
                                <i class="fa fa-calendar-o"></i> <?php echo e($post['date']); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    
    
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\components\sidebar.blade.php ENDPATH**/ ?>