<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>
<?php $__env->startSection('page-description', 'Overview statistik dan aktivitas terbaru'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Stats Cards -->
    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <?php if(auth()->user()->role === 'admin'): ?>
        <!-- Berita Card -->
        <div class="card-hover bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm font-medium">Berita</p>
                    <h3 class="text-3xl font-bold text-gray-800 mt-2"><?php echo e($stats['berita']); ?></h3>
                </div>
                <div class="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center">
                    <i class="fas fa-newspaper text-blue-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?php echo e(route('admin.beritas.index')); ?>" class="mt-4 text-blue-600 text-sm font-medium hover:underline inline-flex items-center">
                Lihat semua <i class="fas fa-arrow-right ml-2 text-xs"></i>
            </a>
        </div>
        
        <!-- Event Card -->
        <div class="card-hover bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm font-medium">Event</p>
                    <h3 class="text-3xl font-bold text-gray-800 mt-2"><?php echo e($stats['event']); ?></h3>
                </div>
                <div class="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center">
                    <i class="fas fa-calendar-alt text-purple-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="mt-4 text-purple-600 text-sm font-medium hover:underline inline-flex items-center">
                Lihat semua <i class="fas fa-arrow-right ml-2 text-xs"></i>
            </a>
        </div>
        
        <!-- Pengumuman Card -->
        <div class="card-hover bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm font-medium">Pengumuman</p>
                    <h3 class="text-3xl font-bold text-gray-800 mt-2"><?php echo e($stats['pengumuman']); ?></h3>
                </div>
                <div class="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center">
                    <i class="fas fa-bullhorn text-green-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?php echo e(route('admin.pengumumans.index')); ?>" class="mt-4 text-green-600 text-sm font-medium hover:underline inline-flex items-center">
                Lihat semua <i class="fas fa-arrow-right ml-2 text-xs"></i>
            </a>
        </div>
        
        <!-- Galeri Card -->
        <div class="card-hover bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm font-medium">Galeri</p>
                    <h3 class="text-3xl font-bold text-gray-800 mt-2"><?php echo e($stats['galeri']); ?></h3>
                </div>
                <div class="w-14 h-14 bg-yellow-100 rounded-2xl flex items-center justify-center">
                    <i class="fas fa-images text-yellow-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?php echo e(route('admin.galeris.index')); ?>" class="mt-4 text-yellow-600 text-sm font-medium hover:underline inline-flex items-center">
                Lihat semua <i class="fas fa-arrow-right ml-2 text-xs"></i>
            </a>
        </div>
        <?php endif; ?>
        
        <!-- Pendaftaran Card -->
        <div class="card-hover bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm font-medium">Pendaftaran</p>
                    <h3 class="text-3xl font-bold text-gray-800 mt-2"><?php echo e($stats['pendaftaran']); ?></h3>
                </div>
                <div class="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center">
                    <i class="fas fa-user-plus text-red-600 text-2xl"></i>
                </div>
            </div>
            <a href="<?php echo e(route('admin.pendaftaran.index')); ?>" class="mt-4 text-red-600 text-sm font-medium hover:underline inline-flex items-center">
                Lihat semua <i class="fas fa-arrow-right ml-2 text-xs"></i>
            </a>
        </div>
    </div>
    
    <?php if(auth()->user()->role === 'admin'): ?>
    <!-- Recent Content -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Berita -->
        <div class="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-gray-800">Berita Terbaru</h3>
                <a href="<?php echo e(route('admin.beritas.index')); ?>" class="text-blue-600 text-sm font-medium hover:underline">Lihat semua</a>
            </div>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $recentBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-start space-x-4 p-3 hover:bg-gray-50 rounded-xl transition-colors">
                        <div class="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                            <?php if($berita->gambar): ?>
                                <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center">
                                    <i class="fas fa-image text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <h4 class="font-medium text-gray-800 truncate"><?php echo e($berita->judul); ?></h4>
                            <p class="text-sm text-gray-500 mt-1"><?php echo e($berita->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-8">Belum ada berita</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Recent Events -->
        <div class="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-gray-800">Event Terbaru</h3>
                <a href="<?php echo e(route('admin.events.index')); ?>" class="text-purple-600 text-sm font-medium hover:underline">Lihat semua</a>
            </div>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $recentEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-start space-x-4 p-3 hover:bg-gray-50 rounded-xl transition-colors">
                        <div class="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                            <?php if($event->gambar): ?>
                                <img src="<?php echo e(asset('storage/' . $event->gambar)); ?>" alt="<?php echo e($event->judul); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center">
                                    <i class="fas fa-calendar text-gray-400"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <h4 class="font-medium text-gray-800 truncate"><?php echo e($event->judul); ?></h4>
                            <p class="text-sm text-gray-500 mt-1"><?php echo e($event->tanggal); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-8">Belum ada event</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>