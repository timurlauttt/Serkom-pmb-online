<?php $__env->startSection('title', 'Detail Paket Wisata'); ?>
<?php $__env->startSection('page-title', 'Detail Paket Wisata'); ?>
<?php $__env->startSection('page-description', 'Lihat detail paket wisata'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="p-6 space-y-4">
            <?php if($paketWisata->gambar): ?>
            <div>
                <img src="<?php echo e(asset($paketWisata->gambar)); ?>" alt="Foto Paket" class="w-full h-48 object-cover rounded mb-4">
            </div>
            <?php endif; ?>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Nama Paket</span>
                <div class="font-semibold text-gray-800"><?php echo e($paketWisata->nama_paket); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Kategori</span>
                <div class="text-gray-700"><?php echo e($paketWisata->kategori ?? '-'); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Durasi</span>
                <div class="text-gray-700"><?php echo e($paketWisata->durasi_hari); ?> hari</div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Harga</span>
                <div class="text-gray-700">Rp <?php echo e(number_format($paketWisata->harga,0,',','.')); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Akomodasi/Hotel</span>
                <div class="text-gray-700">
                    <?php if($paketWisata->akomodasi && is_array($paketWisata->akomodasi) && count($paketWisata->akomodasi) > 0): ?>
                        <ul class="list-disc list-inside">
                            <?php $__currentLoopData = $paketWisata->akomodasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($hotel); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Objek Wisata</span>
                <div class="text-gray-700">
                    <?php if($paketWisata->objek_wisata && is_array($paketWisata->objek_wisata) && count($paketWisata->objek_wisata) > 0): ?>
                        <ul class="list-disc list-inside">
                            <?php $__currentLoopData = $paketWisata->objek_wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($objek); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Slug</span>
                <div class="text-xs text-gray-500 font-mono"><?php echo e($paketWisata->slug); ?></div>
            </div>
            <div>
                <span class="block text-xs text-gray-500 mb-1">Keterangan</span>
                <div class="text-gray-700"><?php echo e($paketWisata->keterangan); ?></div>
            </div>
        </div>
        <div class="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
            <a href="<?php echo e(route('admin.paket-wisata.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-gray-700 hover:bg-gray-300">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\paket-wisata\show.blade.php ENDPATH**/ ?>