<?php $__env->startSection('title', 'Event'); ?>
<?php $__env->startSection('page-title', 'Manajemen Event'); ?>
<?php $__env->startSection('page-description', 'Kelola semua event dan kegiatan sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Actions -->
    <div class="flex justify-between items-center">
        <div>
            <h3 class="text-2xl font-bold text-gray-800">Daftar Event</h3>
            <p class="text-gray-600 mt-1">Total: <?php echo e($events->count()); ?> event</p>
        </div>
        <a href="<?php echo e(route('admin.events.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
            <i class="fas fa-plus mr-2"></i>Tambah Event
        </a>
    </div>

    <!-- Content: Table -->
    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gambar</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Judul</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Deskripsi</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jurusan</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider" style="min-width:160px">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap w-28">
                                        <div class="w-20 h-12 bg-gray-100 rounded overflow-hidden flex items-center justify-center">
                                            <?php if($event->image_path): ?>
                                                <img src="<?php echo e($event->image_url); ?>" alt="<?php echo e($event->title); ?>" class="w-full h-full object-cover">
                                            <?php else: ?>
                                                <i class="fas fa-calendar text-gray-300"></i>
                                            <?php endif; ?>
                                        </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($event->title); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <i class="fas fa-calendar-alt mr-2"></i>
                                <?php echo e(\Carbon\Carbon::parse($event->start_date)->format('d-m-Y')); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-600">
                                        <?php echo e(Str::limit(strip_tags($event->description), 120)); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-xs">
                                                            <td class="px-6 py-4 whitespace-nowrap text-xs">
                                                                <?php if($event->status === 'published'): ?>
                                                                    <span class="inline-block bg-green-100 text-green-800 px-2 py-1 rounded">Published</span>
                                                                <?php else: ?>
                                                                    <span class="inline-block bg-gray-200 text-gray-700 px-2 py-1 rounded">Draft</span>
                                                                <?php endif; ?>
                                <?php if($event->jurusan): ?>
                                    <span class="inline-block bg-yellow-100 text-yellow-800 px-2 py-1 rounded"><?php echo e($event->jurusan->name); ?></span>
                                <?php else: ?>
                                    <span class="inline-block bg-gray-100 text-gray-600 px-2 py-1 rounded">Umum</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-right">
                                <div class="flex space-x-2 justify-end">
                                    <form action="<?php echo e(route('admin.events.toggle-status', $event->slug)); ?>" method="POST" onsubmit="return confirm('Ubah status event ini?')">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="text-green-600 hover:text-green-900 transition-colors" title="Toggle Status">
                                            <?php if($event->status === 'published'): ?>
                                                <i class="fas fa-eye-slash"></i>
                                            <?php else: ?>
                                                <i class="fas fa-upload"></i>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                    <a href="<?php echo e(route('admin.events.show', $event->slug)); ?>" class="text-blue-600 hover:text-blue-900 transition-colors" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.events.edit', $event->slug)); ?>" class="text-yellow-600 hover:text-yellow-900 transition-colors" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.events.destroy', $event->slug)); ?>" method="POST" class="inline"
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus event ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900 transition-colors" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4 mx-auto">
                                    <i class="fas fa-calendar-alt text-gray-400 text-2xl"></i>
                                </div>
                                <div class="text-lg font-semibold text-gray-900">Belum ada event</div>
                                <p class="text-gray-500 mt-2">Mulai dengan menambahkan event pertama.</p>
                                <a href="<?php echo e(route('admin.events.create')); ?>" class="mt-4 inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
                                    <i class="fas fa-plus mr-2"></i>Tambah Event
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\events\index.blade.php ENDPATH**/ ?>