<?php $__env->startSection('title', 'Prestasi'); ?>
<?php $__env->startSection('page-title', 'Manajemen Prestasi'); ?>
<?php $__env->startSection('page-description', 'Kelola semua prestasi siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Actions -->
    <div class="flex justify-between items-center">
        <div>
            <h3 class="text-2xl font-bold text-gray-800">Daftar Prestasi</h3>
            <p class="text-gray-600 mt-1">Total: <?php echo e($prestasis->count()); ?> prestasi</p>
        </div>
        <a href="<?php echo e(route('admin.prestasis.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all font-medium">
            <i class="fas fa-plus mr-2"></i>Tambah Prestasi
        </a>
    </div>

    <!-- Content -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if($prestasis->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thumbnail</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Judul</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tingkat</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Peringkat</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tahun</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Jurusan</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Featured</th>
                            <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $prestasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="w-16 h-16 rounded-lg overflow-hidden bg-gray-200">
                                    <?php if($prestasi->thumbnail): ?>
                                        <img src="<?php echo e(asset($prestasi->thumbnail)); ?>" alt="<?php echo e($prestasi->judul); ?>" class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <div class="w-full h-full flex items-center justify-center">
                                            <i class="fas fa-trophy text-gray-400"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($prestasi->judul); ?></div>
                                <div class="text-sm text-gray-500 mt-1"><?php echo e(Str::limit($prestasi->deskripsi, 60)); ?></div>
                                <?php if($prestasi->nama_siswa): ?>
                                    <div class="text-xs text-blue-600 mt-1"><?php echo e($prestasi->nama_siswa); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php echo e($prestasi->tingkat === 'internasional' ? 'bg-purple-100 text-purple-800' : ''); ?>

                                    <?php echo e($prestasi->tingkat === 'nasional' ? 'bg-red-100 text-red-800' : ''); ?>

                                    <?php echo e($prestasi->tingkat === 'provinsi' ? 'bg-yellow-100 text-yellow-800' : ''); ?>

                                    <?php echo e($prestasi->tingkat === 'kota' ? 'bg-green-100 text-green-800' : ''); ?>

                                    <?php echo e($prestasi->tingkat === 'sekolah' ? 'bg-blue-100 text-blue-800' : ''); ?>">
                                    <?php echo e(ucfirst($prestasi->tingkat)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo e($prestasi->peringkat); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo e($prestasi->tahun); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-xs">
                                <?php if($prestasi->jurusan): ?>
                                    <span class="inline-block bg-indigo-100 text-indigo-800 px-2 py-1 rounded"><?php echo e($prestasi->jurusan->name); ?></span>
                                <?php else: ?>
                                    <span class="inline-block bg-gray-100 text-gray-600 px-2 py-1 rounded">Umum</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($prestasi->is_featured): ?>
                                    <i class="fas fa-star text-yellow-400"></i>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="<?php echo e(route('admin.prestasis.edit', $prestasi->id)); ?>" class="text-yellow-600 hover:text-yellow-900 transition-colors" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.prestasis.destroy', $prestasi->id)); ?>" method="POST" class="inline" 
                                          onsubmit="return confirm('Apakah Anda yakin ingin menghapus prestasi ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900 transition-colors" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                    <i class="fas fa-trophy text-gray-400 text-2xl"></i>
                </div>
                <h5 class="text-lg font-semibold text-gray-900 mb-2">Belum ada prestasi</h5>
                <p class="text-gray-500 mb-6">Mulai dengan menambahkan prestasi pertama.</p>
                <a href="<?php echo e(route('admin.prestasis.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all font-medium inline-flex items-center">
                    <i class="fas fa-plus mr-2"></i>Tambah Prestasi
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Pribadi\smk-taman-siswa-app\resources\views\admin\prestasis\index.blade.php ENDPATH**/ ?>